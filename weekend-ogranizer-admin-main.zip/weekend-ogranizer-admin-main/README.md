# weekend-ogranizer-admin

Стэк технологий

<ul>
    <li>React</li>
    <li>Material-UI</li>
    <li>Redux</li>
    <li>NodeJS</li>
    <li>WebPack5</li>
</ul>

# Env

SERVER = указываем адрес API сервера
