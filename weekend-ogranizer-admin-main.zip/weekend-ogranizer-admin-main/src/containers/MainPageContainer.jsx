import { connect } from "react-redux"
import { push } from "connected-react-router"
import MainPage from "components/MainPage/MainPage"

const mapStateToProps = (store) => {
    return {}
}

const mapDispatchToProps = {
    redirect: push,
}

export default connect(mapStateToProps, mapDispatchToProps)(MainPage)
