import { connect } from "react-redux"
import { push } from "connected-react-router"
import Categories from "components/Categories/Categories"
import {
    getCategoriesAction,
    selectCategoryAction,
    addCategoryAction,
    modifyCategoryAction,
    deleteCategoryAction,
    openModalAction,
    closeModalAction,
} from "actions/categories"

const mapStateToProps = (store) => {
    const {
        categories,
        selectedCategory,
        newCategory,
        loaded,
    } = store.categories

    return {
        categories,
        selectedCategory,
        newCategory,
        loaded,
    }
}

const mapDispatchToProps = {
    redirect: push,
    getCategories: getCategoriesAction,
    selectCategory: selectCategoryAction,
    addCategory: addCategoryAction,
    modifyCategory: modifyCategoryAction,
    deleteCategory: deleteCategoryAction,
    openModal: openModalAction,
    closeModal: closeModalAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(Categories)
