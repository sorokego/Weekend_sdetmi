import { connect } from "react-redux"
import { push } from "connected-react-router"
// import Service from "components/Service/Service"
import ServiceMainPage from "components/Service/Service"
import {
    addServiceAction,
    getServiceByIdAction,
    deleteServiceAction,
    modifyServiceAction,
} from "actions/services"

const mapStateToProps = (store) => {
    const { service, services, newService, loaded } = store.service

    return {
        loaded,
        service,
        services,
        newService,
    }
}

const mapDispatchToProps = {
    redirect: push,
    addService: addServiceAction,
    getService: getServiceByIdAction,
    deleteService: deleteServiceAction,
    modifyService: modifyServiceAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(ServiceMainPage)
