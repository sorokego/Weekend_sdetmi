import { connect } from "react-redux"
import { push } from "connected-react-router"
import ImageDialog from "components/Service/ImageDialog"
import { modifyServiceAction } from "actions/service"

const mapStateToProps = (store) => {
    const { service, newService, showDialog } = store.service
    return {
        service,
        newService,
        showDialog,
    }
}

const mapDispatchToProps = {
    redirect: push,
    modifyService: modifyServiceAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(ImageDialog)
