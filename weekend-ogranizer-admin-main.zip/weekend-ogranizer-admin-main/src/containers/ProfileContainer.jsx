import { connect } from "react-redux"
import { push } from "connected-react-router"
import Profile from "components/Profile/Profile"
import { getUserByIdAction, modifyUserAction } from "actions/users"
import { logoutAction, initProfileAction } from "actions/profile"

const mapStateToProps = (store) => {
    const { profile } = store.profile
    const { selectedUser } = store.users

    return {
        profile,
        selectedUser,
    }
}

const mapDispatchToProps = {
    redirect: push,
    initProfile: initProfileAction,
    modifyUser: modifyUserAction,
    logout: logoutAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(Profile)
