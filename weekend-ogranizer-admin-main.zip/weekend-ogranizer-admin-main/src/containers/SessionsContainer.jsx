import { connect } from "react-redux"
import { push } from "connected-react-router"
import Sessions from "components/Sessions/Sessions"
import {
    getSessionsAction,
    selectSessionAction,
    modifySessionAction,
    openModalAction,
    closeModalAction,
} from "actions/sessions"

const mapStateToProps = (store) => {
    const { sessions, selectedSession, loaded } = store.sessions

    return {
        sessions,
        selectedSession,
        loaded,
    }
}

const mapDispatchToProps = {
    redirect: push,
    getSessions: getSessionsAction,
    selectSession: selectSessionAction,
    modifySession: modifySessionAction,
    openModal: openModalAction,
    closeModal: closeModalAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(Sessions)
