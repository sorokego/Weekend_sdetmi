import { connect } from "react-redux"
import { push } from "connected-react-router"
import Category from "components/Category/Category"
import {
    getCategoryByIdAction,
    addCategoryAction,
    modifyCategoryAction,
    deleteCategoryAction,
} from "actions/categories"

const mapStateToProps = (store) => {
    const {
        selectedCategory,
        newCategory,
        loaded,
        selectedCategoryId,
    } = store.categories

    return {
        selectedCategory,
        newCategory,
        loaded,
        selectedCategoryId,
    }
}

const mapDispatchToProps = {
    redirect: push,
    getCategoryById: getCategoryByIdAction,
    addCategory: addCategoryAction,
    modifyCategory: modifyCategoryAction,
    deleteCategory: deleteCategoryAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(Category)
