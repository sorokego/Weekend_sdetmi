import { connect } from "react-redux"
import { push } from "connected-react-router"
import Tag from "components/Tag/Tag"
import {
    getTagByIdAction,
    addTagAction,
    modifyTagAction,
    deleteTagAction,
} from "actions/tags"

const mapStateToProps = (store) => {
    const { selectedTag, newTag, loaded, selectedTagId } = store.tags

    return {
        selectedTag,
        newTag,
        loaded,
        selectedTagId,
    }
}

const mapDispatchToProps = {
    redirect: push,
    getTagById: getTagByIdAction,
    addTag: addTagAction,
    modifyTag: modifyTagAction,
    deleteTag: deleteTagAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(Tag)
