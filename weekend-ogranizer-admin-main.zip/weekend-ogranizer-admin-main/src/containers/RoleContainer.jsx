import { connect } from "react-redux"
import { push } from "connected-react-router"
import Role from "components/Role/Role"
import {
    getRolesAction,
    selectRoleAction,
    addRoleAction,
    modifyRoleAction,
    getRoleByIdAction,
    deleteRoleAction,
} from "actions/roles"

const mapStateToProps = (store) => {
    const { newRole, selectedRole, selectedRoleId, loaded } = store.roles
    return {
        newRole,
        selectedRole,
        selectedRoleId,
        loaded,
    }
}

const mapDispatchToProps = {
    redirect: push,
    getRoles: getRolesAction,
    selectRole: selectRoleAction,
    addRole: addRoleAction,
    modifyRole: modifyRoleAction,
    getRoleById: getRoleByIdAction,
    deleteRole: deleteRoleAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(Role)
