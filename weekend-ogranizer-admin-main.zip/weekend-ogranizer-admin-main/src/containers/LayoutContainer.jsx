import { connect } from "react-redux"
import { push } from "connected-react-router"
import Layout from "components/Layout/Layout"

const mapStateToProps = (store) => {
    const { globalInit } = store.init

    return {
        globalInit,
    }
}

const mapDispatchToProps = {
    redirect: push,
}

export default connect(mapStateToProps, mapDispatchToProps)(Layout)
