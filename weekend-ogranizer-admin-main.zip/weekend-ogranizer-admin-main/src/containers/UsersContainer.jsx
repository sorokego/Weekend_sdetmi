import { connect } from "react-redux"
import { push } from "connected-react-router"
import Users from "components/Users/Users"
import {
    getUsersAction,
    addUserAction,
    modifyUserAction,
    deleteUserAction,
    selectUserAction,
    getUserByIdAction,
    initAction,
    openModalAction,
    closeModalAction,
} from "actions/users"

import { getRolesAction } from "actions/roles"

const mapStateToProps = (store) => {
    const { users, newUser, selectedUser, loaded, selectedUserId } = store.users
    const { globalInit } = store.init
    const { roles } = store.roles
    return {
        users,
        loaded,
        globalInit,
        newUser,
        selectedUser,
        selectedUserId,
        roles,
    }
}

const mapDispatchToProps = {
    redirect: push,
    getUsers: getUsersAction,
    addUser: addUserAction,
    modifyUser: modifyUserAction,
    deleteUser: deleteUserAction,
    selectUser: selectUserAction,
    init: initAction,
    getRoles: getRolesAction,
    getUserById: getUserByIdAction,
    openModal: openModalAction,
    closeModal: closeModalAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(Users)
