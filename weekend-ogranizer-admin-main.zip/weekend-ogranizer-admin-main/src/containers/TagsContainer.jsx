import { connect } from "react-redux"
import { push } from "connected-react-router"
import Tags from "components/Tags/Tags"
import {
    getTagsAction,
    selectTagAction,
    addTagAction,
    modifyTagAction,
    deleteTagAction,
    openModalAction,
    closeModalAction,
} from "actions/tags"

const mapStateToProps = (store) => {
    const { tags, selectedTag, newTag, loaded } = store.tags

    return {
        tags,
        selectedTag,
        newTag,
        loaded,
    }
}

const mapDispatchToProps = {
    redirect: push,
    getTags: getTagsAction,
    selectTag: selectTagAction,
    addTag: addTagAction,
    modifyTag: modifyTagAction,
    deleteTag: deleteTagAction,
    openModal: openModalAction,
    closeModal: closeModalAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(Tags)
