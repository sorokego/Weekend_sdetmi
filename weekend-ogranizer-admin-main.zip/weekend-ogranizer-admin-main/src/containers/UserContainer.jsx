import { connect } from "react-redux"
import { push } from "connected-react-router"
import User from "components/User/User"
import {
    getUsersAction,
    addUserAction,
    modifyUserAction,
    deleteUserAction,
    selectUserAction,
    getUserByIdAction,
    initAction,
} from "actions/users"

import { getRolesAction } from "actions/roles"

const mapStateToProps = (store) => {
    const { selectedUser, newUser, loaded, selectedUserId } = store.users
    const { roles } = store.roles
    return {
        newUser,
        loaded,
        roles,
        selectedUser,
        selectedUserId,
    }
}

const mapDispatchToProps = {
    redirect: push,
    modifyUser: modifyUserAction,
    deleteUser: deleteUserAction,
    selectUser: selectUserAction,
    addUser: addUserAction,
    getUsers: getUsersAction,
    getUserById: getUserByIdAction,
    getRoles: getRolesAction,
    init: initAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(User)
