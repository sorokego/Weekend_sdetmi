import { connect } from "react-redux"
import { push } from "connected-react-router"
import Roles from "components/Roles/Roles"
import {
    getRolesAction,
    selectRoleAction,
    openModalAction,
    closeModalAction,
    addRoleAction,
} from "actions/roles"

const mapStateToProps = (store) => {
    const { roles, newRole, selectedRole, loaded } = store.roles
    return {
        roles,
        newRole,
        selectedRole,
        loaded,
    }
}

const mapDispatchToProps = {
    redirect: push,
    getRoles: getRolesAction,
    selectRole: selectRoleAction,
    openModal: openModalAction,
    closeModal: closeModalAction,
    addRole: addRoleAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(Roles)
