import { connect } from "react-redux"
import { push } from "connected-react-router"
import Services from "components/Services/Services"
import {
    getServicesAction,
    addServiceAction,
    getServiceByIdAction,
    deleteServiceAction,
    modifyServiceAction,
    selectServiceAction,
} from "actions/services"

const mapStateToProps = (store) => {
    const { service, services, newSerivce, loaded } = store.service

    return {
        service,
        services,
        newSerivce,
        loaded,
    }
}

const mapDispatchToProps = {
    redirect: push,
    addService: addServiceAction,
    getService: getServiceByIdAction,
    deleteService: deleteServiceAction,
    modifyService: modifyServiceAction,
    getServices: getServicesAction,
    selectService: selectServiceAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(Services)
