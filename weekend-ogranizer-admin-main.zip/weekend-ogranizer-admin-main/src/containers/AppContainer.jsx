import { connect } from "react-redux"
import { push } from "connected-react-router"
import App from "components/App/App"
import {
    initAction,
    setInitTrueAction,
    setInitFalseAction,
    startProgressAction,
} from "actions/init"
import { loginAction, logoutAction, initProfileAction } from "actions/profile"

const mapStateToProps = (store) => {
    const { loaded, routers, nav, globalInit, progress } = store.init
    const { loginState, profile } = store.profile
    return {
        loginState,
        progress,
        globalInit,
        profile,
        loaded,
        routers,
        nav,
    }
}

const mapDispatchToProps = {
    handleRedirect: push,
    init: initAction,
    login: loginAction,
    logout: logoutAction,
    initProfile: initProfileAction,
    setInitTrue: setInitTrueAction,
    setInitFalse: setInitFalseAction,
    startProgress: startProgressAction,
}

export default connect(mapStateToProps, mapDispatchToProps)(App)
