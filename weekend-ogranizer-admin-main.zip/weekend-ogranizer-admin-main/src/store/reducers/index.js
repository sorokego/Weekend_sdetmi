import { combineReducers } from "redux"
import { connectRouter } from "connected-react-router"
import { initReducer } from "./init"
import { usersReducer } from "./users"
import { serviceReducer } from "./services"
import { categoriesReducer } from "./categories"
import { tagsReducer } from "./tags"
import { profileReducer } from "./profile"

// import { subCategoriesReducer } from "./subCategories"
import { rolesReducer } from "./roles"
import { sessionsReducer } from "./sessions"

export const createRootReducer = (history) =>
    combineReducers({
        init: initReducer,
        users: usersReducer,
        service: serviceReducer,
        roles: rolesReducer,
        tags: tagsReducer,
        profile: profileReducer,
        categories: categoriesReducer,
        sessions: sessionsReducer,
        // subCategories: subCategoriesReducer,
        router: connectRouter(history),
    })
