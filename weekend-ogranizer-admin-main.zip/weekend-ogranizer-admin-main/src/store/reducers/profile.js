import { LOGIN, LOGOUT, INIT_PROFILE } from "actions/profile"

const initialState = {
    loginState: false,
    profile: {},
}

export const profileReducer = (state = initialState, action) => {
    switch (action.type) {
        case INIT_PROFILE:
            const lsToken = localStorage.token
            return {
                ...state,
                profile: action.payload,
                loginState: lsToken !== null || lsToken !== undefined,
            }

        case LOGIN:
            return {
                ...state,
                loginState: action.payload.token.length > 0,
                profile: action.payload.profile,
            }

        case LOGOUT:
            localStorage.removeItem("token")
            return {
                ...state,
                profile: {},
                loginState: false,
            }
        default:
            return state
    }
}
