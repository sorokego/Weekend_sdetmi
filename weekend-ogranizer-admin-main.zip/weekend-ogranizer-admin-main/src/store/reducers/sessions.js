import {
    GET_SESSIONS,
    GET_SESSION_BY_ID,
    SELECT_SESSION,
    MODIFY_SESSION,
    // DELETE_TAG,
    OPEN_MODAL,
    CLOSE_MODAL,
} from "actions/sessions"

const initialState = {
    sessions: [],
    loaded: false,
    selectedSession: {},
    selectedSessionId: null,
}

export const sessionsReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_SESSIONS:
            return {
                ...state,
                sessions: action.payload.result,
                loaded: true,
                selectedSession: {},
                selectedSessionId: null,
            }

        case GET_SESSION_BY_ID:
            return {
                ...state,
                loaded: true,
                selectedSession: action.payload,
            }

        case SELECT_SESSION:
            return {
                ...state,
                selectedSessionId: action.payload,
                loaded: false,
            }

        case MODIFY_SESSION:
            return {
                ...state,
                selectedSession: {},
                loaded: false,
            }

        case OPEN_MODAL:
            return {
                ...state,
                selectedSession: {},
            }

        case CLOSE_MODAL:
            return {
                ...state,
                selectedSession: {},
            }

        default:
            return state
    }
}
