import {
    GET_SERVICES,
    GET_SERVICE_BY_ID,
    ADD_SERVICE,
    DELETE_SERVICE,
    MODIFY_SERVICE,
    SELECT_SERVICE,
    OPEN_MODAL,
    CLOSE_MODAL,
} from "actions/services"

const initialState = {
    service: {},
    loaded: false,
    services: [],
    newService: false,
}

export const serviceReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_SERVICES:
            return {
                ...state,
                services: action.payload.result,
                loaded: true,
            }

        case ADD_SERVICE:
            return {
                ...state,
                newService: true,
                service: {},
                loaded: false,
            }
        case GET_SERVICE_BY_ID:
            return {
                ...state,
                service: action.payload,
                newService: false,
                loaded: true,
            }
        case DELETE_SERVICE:
            return {
                ...state,
                service: {},
                newService: false,
                loaded: false,
            }
        case MODIFY_SERVICE:
            return {
                ...state,
                service: {},
                newService: false,
                loaded: false,
            }

        case SELECT_SERVICE:
            return {
                ...state,
                service: action.payload,
                newService: false,
                loaded: false,
            }

        case OPEN_MODAL:
            return {
                ...state,
                newService: true,
            }

        case CLOSE_MODAL:
            return {
                ...state,
                newService: false,
            }
        default:
            return state
    }
}
