import {
    GET_CATEGORIES,
    GET_CATEGORY_BY_ID,
    SELECT_CATEGORY,
    ADD_CATEGORY,
    MODIFY_CATEGORY,
    DELETE_CATEGORY,
    OPEN_MODAL,
    CLOSE_MODAL,
} from "actions/categories"

const initialState = {
    categories: [],
    loaded: false,
    selectedCategory: {},
    newCategory: false,
    selectedCategoryId: null,
}

export const categoriesReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_CATEGORIES:
            return {
                ...state,
                categories: action.payload.result,
                loaded: true,
            }

        case GET_CATEGORY_BY_ID:
            return {
                ...state,
                loaded: true,
                selectedCategory: action.payload,
            }

        case SELECT_CATEGORY:
            return {
                ...state,
                selectedCategoryId: action.payload,
                loaded: false,
            }

        case ADD_CATEGORY:
            return {
                ...state,
                loaded: false,
            }
        case MODIFY_CATEGORY:
            return {
                ...state,
                loaded: false,
            }

        case DELETE_CATEGORY:
            return {
                ...state,
                loaded: false,
            }

        case OPEN_MODAL:
            return {
                ...state,
                newCategory: true,
            }

        case CLOSE_MODAL:
            return {
                ...state,
                newCategory: false,
            }

        default:
            return state
    }
}
