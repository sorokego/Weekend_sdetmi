import {
    GET_TAGS,
    GET_TAG_BY_ID,
    SELECT_TAG,
    ADD_TAG,
    MODIFY_TAG,
    DELETE_TAG,
    OPEN_MODAL,
    CLOSE_MODAL,
} from "actions/tags"

const initialState = {
    tags: [],
    loaded: false,
    selectedTag: {},
    newTag: false,
    selectedTagId: null,
}

export const tagsReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_TAGS:
            return {
                ...state,
                tags: action.payload.result,
                loaded: true,
                selectedTag: {},
                selectedTagId: null,
            }

        case GET_TAG_BY_ID:
            return {
                ...state,
                loaded: true,
                selectedTag: action.payload,
            }

        case SELECT_TAG:
            return {
                ...state,
                selectedTagId: action.payload,
                loaded: false,
            }

        case ADD_TAG:
            return {
                ...state,
                loaded: false,
            }
        case MODIFY_TAG:
            return {
                ...state,
                selectedTag: {},
                loaded: false,
            }

        case DELETE_TAG:
            return {
                ...state,
                selectedTag: {},
                loaded: false,
            }

        case OPEN_MODAL:
            return {
                ...state,
                newTag: true,
            }

        case CLOSE_MODAL:
            return {
                ...state,
                newTag: false,
            }

        default:
            return state
    }
}
