import { INIT, INIT_FALSE, INIT_TRUE, START_PROGRESS } from "actions/init"

import MainPageContainer from "containers/MainPageContainer"
import UsersContainer from "containers/UsersContainer"
import UserContainer from "containers/UserContainer"
import ServiceContainer from "containers/ServiceContainer"
import RolesContainer from "containers/RolesContainer"
import RoleContainer from "containers/RoleContainer"
import CategoriesContainer from "containers/CategoriesContainer"
import CategoryContainer from "containers/CategoryContainer"
import ServicesContainer from "containers/ServicesContainer"
import TagsContainer from "containers/TagsContainer"
import TagContainer from "containers/TagContainer"
import SessionsContainer from "containers/SessionsContainer"
import ProfileContainer from "containers/ProfileContainer"

import AccountCircleIcon from "@material-ui/icons/AccountCircle"
import LabelIcon from "@material-ui/icons/Label"
import GroupIcon from "@material-ui/icons/Group"
import ListIcon from "@material-ui/icons/List"
import HomeIcon from "@material-ui/icons/Home"
const initialState = {
    loaded: false,
    progress: true,
    globalInit: false,

    nav: [
        { id: "nav1", name: "Главная", path: "/", event: "", image: HomeIcon },
        {
            id: "nav2",
            name: "Сервисы",
            path: "/services",
            event: "",
            image: ListIcon,
        },
        {
            id: "nav3",
            name: "Категории",
            path: "/categories",
            event: "",
            image: ListIcon,
        },
        {
            id: "nav4",
            name: "Подкатегории",
            path: "/subcategories",
            event: "",
            image: ListIcon,
        },
        {
            id: "nav5",
            name: "Пользователи",
            path: "/users",
            event: "",
            image: AccountCircleIcon,
        },
        {
            id: "nav6",
            name: "Роли",
            path: "/roles",
            event: "",
            image: GroupIcon,
        },
        {
            id: "nav7",
            name: "Тэги",
            path: "/tags",
            event: "",
            image: LabelIcon,
        },
        {
            id: "nav8",
            name: "Заяки",
            path: "/invoices",
            event: "",
            image: LabelIcon,
        },
        {
            id: "nav9",
            name: "Сессии",
            path: "/sessions",
            event: "",
            image: LabelIcon,
        },
    ],
    routers: [
        {
            id: "route1",
            name: "Главная",
            path: "/",
            event: "",
            component: MainPageContainer,
        },
        {
            id: "route2",
            name: "Сервисы",
            path: "/services",
            event: "",
            component: ServicesContainer,
        },
        {
            id: "route3",
            name: "Сервис",
            path: "/services/:id",
            event: "",
            component: ServiceContainer,
        },
        {
            id: "route4",
            name: "Категории",
            path: "/categories",
            event: "",
            component: CategoriesContainer,
        },
        {
            id: "route5",
            name: "Категория",
            path: "/categories/:id",
            event: "",
            component: CategoryContainer,
        },
        // {
        //     name: "Подкатегории",
        //     path: "/subcategories",
        //     event: "",
        //     component: UsersContainer,
        // },
        {
            id: "route6",
            name: "Пользователи",
            path: "/users",
            event: "",
            component: UsersContainer,
        },
        {
            id: "route7",
            name: "Пользователь",
            path: "/users/:id",
            event: "",
            component: UserContainer,
        },
        {
            id: "route8",
            name: "Роли",
            path: "/roles",
            event: "",
            component: RolesContainer,
        },
        {
            id: "route9",
            name: "Роль",
            path: "/roles/:id",
            event: "",
            component: RoleContainer,
        },

        {
            id: "route10",
            name: "Тэги",
            path: "/tags",
            event: "",
            component: TagsContainer,
        },
        {
            id: "route11",
            name: "Тэг",
            path: "/tags/:id",
            event: "",
            component: TagContainer,
        },
        {
            id: "route12",
            name: "Сессии",
            path: "/sessions",
            // notExact: true,
            event: "",
            component: SessionsContainer,
        },
        {
            id: "route13",
            name: "Профиль",
            path: "/profile",
            // notExact: true,
            event: "",
            component: ProfileContainer,
        },
        {
            id: "route99",
            name: "Ошибка",
            path: "/",
            notExact: true,
            event: "",
            component: MainPageContainer,
        },
    ],
}

export const initReducer = (state = initialState, action) => {
    switch (action.type) {
        case INIT:
            return {
                ...state,
                loaded: true,
            }

        case INIT_FALSE:
            return {
                ...state,
                globalInit: false,
            }

        case INIT_TRUE:
            return {
                ...state,
                globalInit: true,
            }

        case START_PROGRESS:
            return { ...state, progress: action.payload }

        default:
            return state
    }
}
