import {
    GET_ROLES,
    GET_ROLE_BY_ID,
    SELECT_ROLE,
    ADD_ROLE,
    MODIFY_ROLE,
    DELETE_ROLE,
    OPEN_MODAL,
    CLOSE_MODAL,
} from "actions/roles"

const initialState = {
    roles: [],
    selectedRole: {},
    selectedRoleId: null,
    newRole: false,
    loaded: false,
}

export const rolesReducer = (state = initialState, action) => {
    switch (action.type) {
        case GET_ROLES:
            return {
                ...state,
                roles: action.payload.result,
                loaded: true,
            }

        case GET_ROLE_BY_ID:
            return {
                ...state,
                selectedRole: action.payload,
                loaded: true,
            }

        case SELECT_ROLE:
            return {
                ...state,
                selectedRoleId: action.payload,
                loaded: false,
            }

        case ADD_ROLE:
            return {
                ...state,
                loaded: false,
            }

        case MODIFY_ROLE:
            return {
                ...state,
                loaded: false,
            }

        case DELETE_ROLE:
            return {
                ...state,
                loaded: false,
            }

        case OPEN_MODAL:
            return {
                ...state,
                newRole: true,
            }

        case CLOSE_MODAL:
            return {
                ...state,
                newRole: false,
                loaded: false,
            }

        default:
            return state
    }
}
