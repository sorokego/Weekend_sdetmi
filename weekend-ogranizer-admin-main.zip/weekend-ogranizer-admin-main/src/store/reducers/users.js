import {
    GET_USERS,
    GET_USER_BY_ID,
    ADD_USER,
    MODIFY_USER,
    DELETE_USER,
    SELECT_USER,
    OPEN_MODAL,
    CLOSE_MODAL,
} from "actions/users"

const initialState = {
    users: [],
    selectedUser: {},
    selectedUserId: null,
    newUser: false,
    loaded: false,
}

export const usersReducer = (state = initialState, action) => {
    switch (action.type) {
        case MODIFY_USER:
            return {
                ...state,
                // loaded: false,
                newUser: false,
            }

        case GET_USER_BY_ID:
            return {
                ...state,
                selectedUser: action.payload,
                // loaded: true,
                // newUser: false,
            }

        case GET_USERS:
            return {
                ...state,
                users: action.payload.result,
                // loaded: true,
                // selectedUser: {},
            }

        case ADD_USER:
            return {
                ...state,
                selectedUser: action.payload,
                newUser: false,
                // loaded: false,
            }

        case DELETE_USER:
            return {
                ...state,
                newUser: false,
                // loaded: false,
            }

        case SELECT_USER:
            return {
                ...state,
                // newUser: false,
                selectedUser: action.payload,
                // loaded: false,
                selectedUserId: action.payload.id,
            }

        case OPEN_MODAL:
            return {
                ...state,
                newUser: true,
                // selectedUser: {},
                // selectedUserId: null,
            }
        case CLOSE_MODAL:
            return {
                ...state,
                newUser: false,
                // selectedUser: {},
                // selectedUserId: null,
            }
        default:
            return state
    }
}
