import { createStore, applyMiddleware } from "redux"
import { composeWithDevTools } from "redux-devtools-extension"
import { createRootReducer } from "reducers"
import { createBrowserHistory } from "history"
import { routerMiddleware } from "connected-react-router"
import { usersMiddleWare } from "middlewares/users.middleware"
import { rolesMiddleWare } from "middlewares/roles.middleware"
import { categoriesMiddleWare } from "middlewares/categories.middleware"
import { tagsMiddleWare } from "middlewares/tags.middleware"
import { sessionsMiddleWare } from "middlewares/sessions.middleware"
import { servicesMiddleWare } from "middlewares/services.middleware"
import { profileMiddleWare } from "middlewares/profile.middleware"
// import { paramsMiddleWare } from "./middlewares/paramsMiddleWare"
import logger from "redux-logger"
export const history = createBrowserHistory()

// logger, only dev

export const initStore = () => {
    const initialStore = {}
    const store = createStore(
        createRootReducer(history),
        initialStore,
        composeWithDevTools(
            applyMiddleware(
                categoriesMiddleWare,
                rolesMiddleWare,
                usersMiddleWare,
                sessionsMiddleWare,
                servicesMiddleWare,
                profileMiddleWare,
                tagsMiddleWare,
                logger,
                routerMiddleware(history)
            )
        )
    )

    return { store }
}
