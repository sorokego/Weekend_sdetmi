export const GET_CATEGORIES = "GET_CATEGORIES"
export const GET_CATEGORY_BY_ID = "GET_CATEGORY_BY_ID"
export const SELECT_CATEGORY = "SELECT_CATEGORY"
export const ADD_CATEGORY = "ADD_CATEGORY"
export const MODIFY_CATEGORY = "MODIFY_CATEGORY"
export const DELETE_CATEGORY = "DELETE_CATEGORY"
export const OPEN_MODAL = "OPEN_MODAL"
export const CLOSE_MODAL = "CLOSE_MODAL"
export const getCategoriesAction = () => ({
    type: GET_CATEGORIES,
})

export const getCategoryByIdAction = (id) => ({
    type: GET_CATEGORY_BY_ID,
    payload: id,
})

export const selectCategoryAction = (id) => ({
    type: SELECT_CATEGORY,
    payload: id,
})

export const addCategoryAction = (category) => ({
    type: ADD_CATEGORY,
    payload: category,
})

export const modifyCategoryAction = (category) => ({
    type: MODIFY_CATEGORY,
    payload: category,
})

export const deleteCategoryAction = (id) => ({
    type: DELETE_CATEGORY,
    payload: id,
})

export const openModalAction = () => ({
    type: OPEN_MODAL,
})

export const closeModalAction = () => ({
    type: CLOSE_MODAL,
})
