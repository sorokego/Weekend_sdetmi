export const GET_ROLES = "GET_ROLES"
export const GET_ROLE_BY_ID = "GET_ROLE"
export const SELECT_ROLE = "SELECT_ROLE"
export const ADD_ROLE = "ADD_ROLE"
export const MODIFY_ROLE = "MODIFY_ROLE"
export const DELETE_ROLE = "DELETE_ROLE"
export const CREATE_ROLE = "CREATE_ROLE"
export const OPEN_MODAL = "OPEN_MODAL"
export const CLOSE_MODAL = "CLOSE_MODAL"

export const getRolesAction = () => ({
    type: GET_ROLES,
})

export const getRoleByIdAction = (id) => ({
    type: GET_ROLE_BY_ID,
    payload: id,
})

export const selectRoleAction = (id) => ({
    type: SELECT_ROLE,
    payload: id,
})

export const addRoleAction = (role) => ({
    type: ADD_ROLE,
    payload: role,
})

export const modifyRoleAction = (role) => ({
    type: MODIFY_ROLE,
    payload: role,
})

export const deleteRoleAction = (id) => ({
    type: DELETE_ROLE,
    payload: id,
})

export const openModalAction = () => ({
    type: OPEN_MODAL,
})

export const closeModalAction = () => ({
    type: CLOSE_MODAL,
})
