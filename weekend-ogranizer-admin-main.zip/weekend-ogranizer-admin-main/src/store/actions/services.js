export const GET_SERVICES = "GET_SERVICES"
export const GET_SERVICE_BY_ID = "GET_SERVICE_BY_ID"
export const ADD_SERVICE = "ADD_SERVICE"
export const DELETE_SERVICE = "DELETE_SERVICE"
export const MODIFY_SERVICE = "MODIFY_SERVICE"
export const CREATE_SERVICE = "CREATE_SERVICE"
export const SELECT_SERVICE = "SELECT_SERVICE"
export const OPEN_MODAL = "OPEN_MODAL"
export const CLOSE_MODAL = "CLOSE_MODAL"

export const getServicesAction = () => ({
    type: GET_SERVICES,
})

export const addServiceAction = (service) => ({
    type: ADD_SERVICE,
    payload: service,
})

export const getServiceByIdAction = (id) => ({
    type: GET_SERVICE_BY_ID,
    payload: id,
})

export const deleteServiceAction = (id) => ({
    type: DELETE_SERVICE,
    payload: id,
})

export const modifyServiceAction = (service) => ({
    type: MODIFY_SERVICE,
    payload: service,
})

export const selectServiceAction = (serivce) => ({
    type: SELECT_SERVICE,
    payload: serivce,
})
export const openModalAction = () => ({
    type: OPEN_MODAL,
})

export const closeModalAction = () => ({
    type: CLOSE_MODAL,
})
