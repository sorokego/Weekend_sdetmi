export const LOGIN = "LOGIN"
export const LOGOUT = "LOGOUT"
export const INIT_PROFILE = "INIT_PROFILE"

export const loginAction = (user) => ({
    type: LOGIN,
    payload: user,
})

export const logoutAction = () => ({
    type: LOGOUT,
})

export const initProfileAction = () => ({
    type: INIT_PROFILE,
})
