export const GET_USERS = "GET_USERS"
export const GET_USER_BY_ID = "GET_USER_BY_ID"

export const ADD_USER = "ADD_USER"
export const MODIFY_USER = "MODIFY_USER"
export const DELETE_USER = "DELETE_USER"
export const CREATE_USER = "CREATE_USER"
export const SELECT_USER = "SELECT_USER"
export const INIT = "INIT"
export const OPEN_MODAL = "OPEN_MODAL"
export const CLOSE_MODAL = "CLOSE_MODAL"

export const initAction = () => ({
    type: INIT,
})

export const getUserByIdAction = (id) => ({
    type: GET_USER_BY_ID,
    payload: id,
})

export const getUsersAction = () => ({
    type: GET_USERS,
})

export const addUserAction = (user) => ({
    type: ADD_USER,
    payload: user,
})

export const modifyUserAction = (user) => ({
    type: MODIFY_USER,
    payload: user,
})

export const deleteUserAction = (user) => ({
    type: DELETE_USER,
    payload: user,
})

export const selectUserAction = (user) => ({
    type: SELECT_USER,
    payload: user,
})

export const createUserAction = () => ({
    type: CREATE_USER,
})
export const openModalAction = () => ({
    type: OPEN_MODAL,
})
export const closeModalAction = () => ({
    type: CLOSE_MODAL,
})
