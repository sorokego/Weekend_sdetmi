export const GET_SESSIONS = "GET_SESSIONS"
export const GET_SESSION_BY_ID = "GET_SESSION_BY_ID"
export const SELECT_SESSION = "SELECT_SESSION"
export const MODIFY_SESSION = "MODIFY_SESSION"
export const OPEN_MODAL = "OPEN_MODAL"
export const CLOSE_MODAL = "CLOSE_MODAL"

export const getSessionsAction = () => ({
    type: GET_SESSIONS,
})

export const getSessionByIdAction = (sessionId) => ({
    type: GET_SESSION_BY_ID,
    payload: sessionId,
})

export const selectSessionAction = (session) => ({
    type: SELECT_SESSION,
    payload: session,
})

export const modifySessionAction = (session) => ({
    type: MODIFY_SESSION,
    payload: session,
})

export const openModalAction = () => ({
    type: OPEN_MODAL,
})
export const closeModalAction = () => ({
    type: CLOSE_MODAL,
})
