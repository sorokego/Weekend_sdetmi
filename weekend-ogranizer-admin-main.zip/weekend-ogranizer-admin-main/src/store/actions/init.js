export const INIT = "INIT"
export const START_PROGRESS = "START_PROGRESS"
export const LOGIN = "LOGIN"
export const LOGOUT = "LOGOUT"
export const INIT_TRUE = "INIT_TRUE"
export const INIT_FALSE = "INIT_FALSE"

export const initAction = () => ({
    type: INIT,
})

export const startProgressAction = (state) => ({
    type: START_PROGRESS,
    payload: state,
})

export const loginAction = (user) => ({
    type: LOGIN,
    payload: user,
})

export const logoutAction = () => ({
    type: LOGOUT,
})

export const setInitTrueAction = () => ({
    type: INIT_TRUE,
})

export const setInitFalseAction = () => ({
    type: INIT_FALSE,
})
