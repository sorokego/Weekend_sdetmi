export const GET_TAGS = "GET_TAGS"
export const GET_TAG_BY_ID = "GET_TAG_BY_ID"
export const SELECT_TAG = "SELECT_TAG"
export const ADD_TAG = "ADD_TAG"
export const MODIFY_TAG = "MODIFY_TAG"
export const DELETE_TAG = "DELETE_TAG"
export const OPEN_MODAL = "OPEN_MODAL"
export const CLOSE_MODAL = "CLOSE_MODAL"
export const getTagsAction = () => ({
    type: GET_TAGS,
})

export const getTagByIdAction = (id) => ({
    type: GET_TAG_BY_ID,
    payload: id,
})

export const selectTagAction = (id) => ({
    type: SELECT_TAG,
    payload: id,
})

export const addTagAction = (tag) => ({
    type: ADD_TAG,
    payload: tag,
})

export const modifyTagAction = (tag) => ({
    type: MODIFY_TAG,
    payload: tag,
})

export const deleteTagAction = (id) => ({
    type: DELETE_TAG,
    payload: id,
})

export const openModalAction = () => ({
    type: OPEN_MODAL,
})

export const closeModalAction = () => ({
    type: CLOSE_MODAL,
})
