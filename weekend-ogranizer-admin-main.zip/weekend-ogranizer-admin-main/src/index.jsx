import React from "react"
import ReactDOM from "react-dom"
import { ConnectedRouter } from "connected-react-router"
import { history } from "./store/store"
import AppContainer from "containers/AppContainer"
import { Provider } from "react-redux"
import "./asset/css/style.css"
import { initStore } from "./store/store"
const { store } = initStore()

ReactDOM.render(
    <Provider store={store}>
        <ConnectedRouter history={history}>
            <AppContainer />
        </ConnectedRouter>
    </Provider>,
    document.getElementById("root")
)
