import { makeStyles } from "@material-ui/core"

const useStyles = makeStyles((theme) => ({
    root: {},
    title: {
        marginBottom: theme.spacing(2),
    },

    divider: {
        marginBottom: theme.spacing(2),
    },
    card: {
        cursor: "pointer",
    },
}))

export default useStyles
