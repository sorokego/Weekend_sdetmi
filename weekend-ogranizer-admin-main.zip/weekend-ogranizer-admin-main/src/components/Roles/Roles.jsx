import React, { useState, useEffect, useLayoutEffect } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import {
    Button,
    Card,
    CardContent,
    Divider,
    Grid,
    Typography,
    ButtonGroup,
} from "@material-ui/core"

import AutorenewRoundedIcon from "@material-ui/icons/AutorenewRounded"
import AppsRoundedIcon from "@material-ui/icons/AppsRounded"
import ReorderRoundedIcon from "@material-ui/icons/ReorderRounded"
import AddCircleRoundedIcon from "@material-ui/icons/AddCircleRounded"

import NewRole from "components/Role/NewRole"
import LayoutContainer from "containers/LayoutContainer"

const Roles = (props) => {
    const {
        roles,
        selectRole,
        getRoles,
        redirect,
        newRole,
        addRole,
        openModal,
        closeModal,
    } = props

    const classes = useStyles()
    const [hover, setHover] = useState(false)
    const [timer, setTimer] = useState(0)

    const [sortElement, setSortElement] = useState(4)

    const handleSortElement = () => {
        const newSortElement = sortElement === 4 ? 12 : 4
        setSortElement(newSortElement)
    }
    useLayoutEffect(() => {
        getRoles()
    }, [])

    useEffect(() => {
        if (roles.length <= 0 && timer < 5) {
            setTimeout(() => {
                setTimer(timer + 1)
            }, 1000)
        }
    })

    const handleSelectRole = (role) => {
        const { id } = role
        selectRole(id)
        redirect(`/roles/${id}`)
    }

    const onMouseEnter = (id) => {
        setHover(id)
    }
    const onMouseLeave = () => {
        setHover(false)
    }

    return (
        <>
            <Typography variant="h4" component="h3" className={classes.title}>
                {props.name}
            </Typography>

            <ButtonGroup
                className={classes.divider}
                color="primary"
                variant="contained"
            >
                <Button onClick={openModal}>
                    <AddCircleRoundedIcon />
                </Button>
                <Button onClick={getRoles}>
                    <AutorenewRoundedIcon />
                </Button>
                <Button variant="outlined" onClick={handleSortElement}>
                    {sortElement === 12 ? (
                        <AppsRoundedIcon />
                    ) : (
                        <ReorderRoundedIcon />
                    )}
                </Button>
            </ButtonGroup>

            <LayoutContainer>
                <Grid container spacing={2}>
                    {roles.length === 0 ? (
                        <Typography>
                            {timer < 5 ? "Загрузка" : "Данных нет"}
                        </Typography>
                    ) : (
                        roles.map((item) => (
                            <Grid item xs={sortElement} key={item.id}>
                                <Card
                                    className={classes.card}
                                    raised={item.id === hover ? true : false}
                                    onMouseEnter={() => onMouseEnter(item.id)}
                                    onMouseLeave={onMouseLeave}
                                    onClick={() => handleSelectRole(item)}
                                >
                                    <CardContent>
                                        <Typography>{item.name}</Typography>
                                        <Typography>
                                            {item.isActive
                                                ? "Активна"
                                                : "Неактивна"}
                                        </Typography>
                                    </CardContent>
                                </Card>
                            </Grid>
                        ))
                    )}
                </Grid>
            </LayoutContainer>

            <NewRole
                newRole={newRole}
                addRole={addRole}
                closeModal={closeModal}
            />
        </>
    )
}

Roles.propTypes = {
    roles: PropTypes.array.isRequired,
    selectRole: PropTypes.func.isRequired,
    getRoles: PropTypes.func.isRequired,
    redirect: PropTypes.func.isRequired,
    newRole: PropTypes.bool.isRequired,
    addRole: PropTypes.func.isRequired,
    openModal: PropTypes.func.isRequired,
    closeModal: PropTypes.func.isRequired,
}

export default Roles
