import React, { useState } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import { TextField, MenuItem, Chip, Avatar } from "@material-ui/core"
import DoneIcon from "@material-ui/icons/Done"

const categories = [
    { id: 1, name: "Категория 1" },
    { id: 2, name: "Категория 2" },
    { id: 3, name: "Категория 3" },
    { id: 4, name: "Категория 4" },
]

const ServiceMainPage = (props) => {
    const { service, newService, handleChangeData } = props
    const [category, setCategory] = useState(categories[0])
    const [selectedCategories, setSelectedCategories] = useState([])
    const [data, setData] = React.useState({})

    React.useLayoutEffect(() => {
        if (!newService) {
            setData(service)
        }
    }, [service])

    const classes = useStyles()

    const handleChange = (e) => {
        const result = categories.find(
            (item) => item.id === parseInt(e.target.value)
        )

        const checkCategory = selectedCategories.find(
            (item) => item.id === parseInt(e.target.value)
        )

        if (checkCategory) {
            return
        } else {
            setCategory(result)
            setSelectedCategories([...selectedCategories, result])
        }
    }

    const handleDelete = (value) => {
        const result = selectedCategories.filter(
            (item) => item.id !== parseInt(value.id)
        )
        setSelectedCategories(result)
    }

    return (
        <div className={classes.blockContainer}>
            <TextField
                fullWidth
                size="small"
                id="name"
                variant="outlined"
                label="Имя"
                className={classes.textField}
                onChange={(e) => handleChangeData(e)}
                value={data.name}
            />
            <TextField
                multiline
                id="desc"
                fullWidth
                size="small"
                variant="outlined"
                label="Описание"
                rows={7}
                className={classes.textField}
                value={data.desc}
                onChange={(e) => handleChangeData(e)}
            />
            <div className={classes.chipContainer}>
                {selectedCategories.length <= 0
                    ? null
                    : selectedCategories.map((item) => (
                          <Chip
                              key={item.id}
                              avatar={<Avatar>C</Avatar>}
                              label={item.name}
                              clickable
                              color="primary"
                              onDelete={() => handleDelete(item)}
                              className={classes.chip}
                              // deleteIcon={<DoneIcon />}
                          />
                      ))}
            </div>
            <TextField
                select
                margin="dense"
                label="Категория"
                id="category"
                className={classes.textField}
                variant="outlined"
                size="small"
                helperText="Укажите категорию"
                onChange={handleChange}
                value={category.id}
            >
                {categories.map((categoryItem) => (
                    <MenuItem key={categoryItem.id} value={categoryItem.id}>
                        {categoryItem.name}
                    </MenuItem>
                ))}
            </TextField>
        </div>
    )
}

ServiceMainPage.propTypes = {}

export default ServiceMainPage
