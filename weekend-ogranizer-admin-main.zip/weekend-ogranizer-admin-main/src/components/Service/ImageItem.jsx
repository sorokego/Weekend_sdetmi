import React from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import {
    ListItem,
    ListItemText,
    Card,
    CardMedia,
    CardContent,
    Typography,
} from "@material-ui/core"

const ImageItem = (props) => {
    const classes = useStyles()
    const { id, name, primary, isActive, desc, src } = props.image

    const handleOpen = () => {}

    return (
        <Card onClick={handleOpen}>
            <CardMedia image={src} className={classes.cardImage} />
            <CardContent>
                <Typography>{name}</Typography>
                <Typography>
                    {primary ? "Основная" : "Дополнительное"}
                </Typography>
            </CardContent>
        </Card>
    )
}

ImageItem.propTypes = {}

export default ImageItem
