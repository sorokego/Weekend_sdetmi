import React from "react"
import PropTypes from "prop-types"

import useStyles from "./style"
import {
    Button,
    Card,
    CardMedia,
    TextField,
    DialogActions,
    DialogTitle,
    DialogContent,
    Dialog,
    Paper,
    Grid,
    MenuItem,
} from "@material-ui/core"
import Draggable from "react-draggable"

const defaultImg = "/img/noimage.png"

const statusDict = [
    { id: 1, name: "Активно", value: true },
    { id: 2, name: "Неактивно", value: false },
]

function PaperComponent(props) {
    return (
        <Draggable
            handle="#draggable-dialog-title"
            cancel={'[class*="MuiDialogContent-root"]'}
        >
            <Paper {...props} />
        </Draggable>
    )
}

const ImageDialog = (props) => {
    const classes = useStyles()

    const { redirect, modifyService, showDialog, addImage, image } = props

    const [data, setData] = React.useState({})
    const [name, setName] = React.useState("")
    const [imageSrc, setImageSrc] = React.useState("")
    const [open, setOpen] = React.useState(showDialog)
    const [active, setActive] = React.useState(true)
    const [desc, setDesc] = React.useState("")

    const handleSave = () => {
        addImage({
            name: name,
            image: imageSrc,
            isActive: active,
            order: 0,
            primary: true,
        })
        handleClose()
    }

    const handleClose = () => {
        setOpen(false)
    }
    const hanldeChangeName = (e) => {
        setName(e.target.value)
    }

    const handleActiveChange = (e) => {
        setActive(e.target.value)
    }

    return (
        <Dialog
            open={open}
            onClose={handleClose}
            PaperComponent={PaperComponent}
            aria-labelledby="draggable-dialog-title"
            fullWidth
            maxWidth="lg"
        >
            <DialogTitle
                onClose={handleClose}
                style={{ cursor: "move" }}
                id="draggable-dialog-title"
            >
                Новое изображение
            </DialogTitle>
            <DialogContent dividers>
                <Grid container spacing={2} className={classes.grid}>
                    <Grid item xs={7}>
                        <TextField
                            margin="dense"
                            variant="outlined"
                            size="small"
                            id="name"
                            label="Имя"
                            className={classes.imageName}
                            onChange={hanldeChangeName}
                            value={name}
                        />
                        <TextField
                            margin="dense"
                            variant="outlined"
                            size="small"
                            id="order"
                            label="Порядок"
                            className={classes.imageName}
                            onChange={hanldeChangeName}
                            value={name}
                        />
                        <TextField
                            margin="dense"
                            variant="outlined"
                            size="small"
                            id="isActive"
                            label="Статус"
                            select
                            value={active}
                            className={classes.imageName}
                            onChange={(e) => handleActiveChange(e)}
                        >
                            {statusDict.map((item) => (
                                <MenuItem key={item.id} value={item.value}>
                                    {item.name}
                                </MenuItem>
                            ))}
                        </TextField>
                        <TextField
                            fullWidth
                            margin="dense"
                            size="small"
                            label="Описание"
                            onChange={(e) => setDesc(e.target.value)}
                            rows="7"
                            multiline
                            variant="outlined"
                            value={desc}
                        />
                    </Grid>
                    <Grid item xs={5} className={classes.gridImageBlock}>
                        <CardMedia
                            className={classes.image}
                            image={defaultImg}
                        />
                        <div className={classes.imageButtonGroup}>
                            <Button
                                variant="contained"
                                color="primary"
                                size="small"
                            >
                                Загрузить
                            </Button>
                            <Button
                                variant="contained"
                                color="default"
                                size="small"
                            >
                                Отчистить
                            </Button>
                        </div>
                    </Grid>
                </Grid>
            </DialogContent>
            <DialogActions>
                <Button
                    variant="contained"
                    color="secondary"
                    size="small"
                    onClick={handleClose}
                >
                    Отмена
                </Button>
                <Button
                    variant="contained"
                    color="primary"
                    size="small"
                    onClick={handleSave}
                >
                    Сохранить
                </Button>
            </DialogActions>
        </Dialog>
    )
}

ImageDialog.propTypes = {}

export default ImageDialog
