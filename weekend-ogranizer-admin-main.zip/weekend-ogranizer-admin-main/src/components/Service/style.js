import { makeStyles } from "@material-ui/core"

const useStyles = makeStyles((theme) => ({
    wrapper: {
        display: "flex",
        flexDirection: "column",
    },
    root: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.paper,
        display: "flex",
    },
    chipContainer: {
        width: "100%",
        maxWidth: "70%",
    },
    chip: {
        margin: theme.spacing(0, 1, 1, 0),
    },
    textField: {
        marginBottom: theme.spacing(1),
    },
    navButton: {
        "&:not(:last-child)": {
            marginRight: theme.spacing(2),
        },
    },
    buttonGroup: {
        width: "100%",
        flexGrow: 1,
        display: "flex",
        alignSelf: "flex-end",
        justifyContent: "flex-end",
    },
    imageCard: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: theme.spacing(2),
    },
    image: {
        height: 300,
        width: 300,
        marginBottom: theme.spacing(4),
    },
    imageName: {
        flexGrow: 1,
        marginRight: theme.spacing(1),
        alignSelf: "center",
    },
    cardImage: {
        height: 100,
    },

    grid: {
        marginBottom: theme.spacing(2),
    },

    gridImageBlock: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
    },
    imageButtonGroup: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        "& > *:not(:last-child)": {
            marginRight: theme.spacing(2),
        },
    },
    cardButtonGroup: {
        display: "flex",
        width: "100%",
        justifyContent: "flex-end",
        alignItems: "center",
        "& > *:not(:last-child)": {
            marginRight: theme.spacing(2),
        },
    },
}))

export default useStyles
