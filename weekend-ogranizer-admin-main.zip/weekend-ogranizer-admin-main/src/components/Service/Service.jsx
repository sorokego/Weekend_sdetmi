import React from "react"
import PropTypes from "prop-types"
import {
    Tabs,
    Tab,
    Typography,
    Box,
    Divider,
    Button,
    List,
} from "@material-ui/core"
import useStyles from "./style"
import ImageItem from "./ImageItem"
import ServiceMainPage from "./ServiceMainPage"
import defaultImg from "asset/img/noimage.png"
// const defaultImg = "/img/noimage.png"

function TabPanel(props) {
    const { children, value, index, ...other } = props

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`vertical-tabpanel-${index}`}
            aria-labelledby={`vertical-tab-${index}`}
            style={{
                flexGrow: 1,
            }}
            {...other}
        >
            {value === index && (
                <Box p={3}>
                    {children}
                    {/* <Typography>{children}</Typography> */}
                </Box>
            )}
        </div>
    )
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
}

function a11yProps(index) {
    return {
        id: `vertical-tab-${index}`,
        "aria-controls": `vertical-tabpanel-${index}`,
    }
}

export default function Service(props) {
    const { service, newService, addService } = props
    const classes = useStyles()
    const [value, setValue] = React.useState(0)

    const [data, setData] = React.useState({})

    const [imageList, setImageList] = React.useState([])

    const handleAddService = () => {}

    const addNewImage = () => {
        setImageList([
            ...imageList,
            {
                order: imageList.length,
                src: defaultImg,
                name: "",
                isActive: true,
            },
        ])
    }

    const handleChangeData = (e) => {
        console.log(e)
        setData({ ...data, [e.target.id]: e.target.value })
    }

    React.useLayoutEffect(() => {
        if (!newService) {
            setData(service)
        }
    }, [service])

    const handleChange = (event, newValue) => {
        if (newValue < 0 || newValue > 4) {
            newValue = 0
        }

        setValue(newValue)
    }

    const handleAddImage = (data) => {
        setImageList([...imageList, data])
    }

    return (
        <>
            <Typography variant="h4" component="h3">
                {!newService ? `Сервис: ${service.name}` : "Новый сервис"}
            </Typography>
            <Divider />
            <div className={classes.wrapper}>
                <div className={classes.root}>
                    <Tabs
                        orientation="vertical"
                        variant="scrollable"
                        indicatorColor="primary"
                        textColor="primary"
                        value={value}
                        onChange={handleChange}
                        aria-label="Vertical tabs example"
                        className={classes.tabs}
                    >
                        <Tab label="Основное" {...a11yProps(0)} />
                        <Tab label="Дополнительное" {...a11yProps(1)} />
                        <Tab label="Подкатегории" {...a11yProps(2)} />
                        <Tab label="Тэги" {...a11yProps(3)} />
                        <Tab label="Изображения" {...a11yProps(3)} />
                    </Tabs>
                    <TabPanel value={value} index={0}>
                        <ServiceMainPage
                            handleChange={handleChange}
                            value={value}
                            service={data}
                            newService={newService}
                            handleChangeData={handleChangeData}
                        />
                    </TabPanel>
                    <TabPanel value={value} index={1}>
                        Дополнительное
                    </TabPanel>
                    <TabPanel value={value} index={2}>
                        Подкатегории
                    </TabPanel>
                    <TabPanel value={value} index={3}>
                        Тэги
                    </TabPanel>
                    <TabPanel value={value} index={4}>
                        <div
                            style={{ display: "flex", flexDirection: "column" }}
                        >
                            <Button
                                onClick={addNewImage}
                                variant="contained"
                                size="small"
                            >
                                Добавить
                            </Button>
                            <div style={{ display: "flex", flexWrap: "wrap" }}>
                                {imageList.map((item, idx) => (
                                    <ImageItem
                                        key={item.order}
                                        image={item}
                                        addImage={handleAddImage}
                                    />
                                ))}
                            </div>
                        </div>
                    </TabPanel>
                </div>

                <div className={classes.buttonGroup}>
                    <Button
                        className={classes.navButton}
                        variant="contained"
                        color="primary"
                        onClick={(e) => handleChange(e, value - 1)}
                    >
                        Назад
                    </Button>
                    <Button
                        className={classes.navButton}
                        variant="contained"
                        color="primary"
                        onClick={(e) => handleChange(e, value + 1)}
                    >
                        Далее
                    </Button>
                    <Button
                        variant="contained"
                        color="secondary"
                        className={classes.navButton}
                    >
                        Отмена
                    </Button>
                    <Button
                        variant="contained"
                        color="primary"
                        disabled={value !== 3}
                        className={classes.navButton}
                    >
                        Сохнанить
                    </Button>
                </div>
            </div>
        </>
    )
}
