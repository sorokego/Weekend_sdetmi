import React, { useEffect, useState } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import { Typography } from "@material-ui/core"

const Footer = (props) => {
    const {} = props
    const classes = useStyles()
    const [date, setDate] = useState(new Date().toLocaleString())

    useEffect(() => {
        const timer = setInterval(() => {
            const result = new Date()
            setDate(result.toLocaleString())
        }, 1000)
        // return clearInterval(timer)
    }, [])

    return (
        <footer className={classes.root}>
            <Typography
                component="span"
                variant="body2"
                color="textSecondary"
                className={classes.name}
            >
                Панель управления версия
            </Typography>
            <Typography
                component="span"
                variant="body2"
                color="textSecondary"
                className={classes.version}
            >
                0.0.1
            </Typography>
            <Typography
                component="span"
                variant="body2"
                color="textSecondary"
                className={classes.date}
            >
                {date}
            </Typography>
        </footer>
    )
}

Footer.propTypes = {}

export default Footer
