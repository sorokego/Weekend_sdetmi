import { makeStyles } from "@material-ui/core"

const useStyles = makeStyles((theme) => ({
    root: {
        backgroundColor: theme.palette.divider,
        display: "flex",
        justifyContent: "space-between",
    },
    name: {
        maxWidth: "33%",
        display: "block",
    },
    version: {
        flexGrow: 1,
        display: "block",
        textAlign: "center",
    },
    date: {
        maxWidth: "33%",
        display: "block",
    },
}))

export default useStyles
