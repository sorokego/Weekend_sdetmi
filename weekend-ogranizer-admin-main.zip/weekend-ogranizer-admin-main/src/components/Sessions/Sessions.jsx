import React, { useState, useEffect, useLayoutEffect } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import {
    Button,
    Card,
    CardContent,
    Divider,
    Grid,
    Typography,
    ButtonGroup,
} from "@material-ui/core"
import LayoutContainer from "containers/LayoutContainer"

import AutorenewRoundedIcon from "@material-ui/icons/AutorenewRounded"
import AppsRoundedIcon from "@material-ui/icons/AppsRounded"
import ReorderRoundedIcon from "@material-ui/icons/ReorderRounded"

const Sessions = (props) => {
    const { sessions, selectSession, getSessions, redirect } = props

    const classes = useStyles()
    const [hover, setHover] = useState(false)
    const [sortElement, setSortElement] = useState(4)

    const handleSortElement = () => {
        const newSortElement = sortElement === 4 ? 12 : 4
        setSortElement(newSortElement)
    }

    useLayoutEffect(() => {
        getSessions()
    }, [])

    const handleSelectSession = (sesison) => {
        selectSession(sesison.id)
        redirect(`/sessions/${sesison.id}`)
    }

    const onMouseEnter = (id) => {
        setHover(id)
    }
    const onMouseLeave = () => {
        setHover(false)
    }

    return (
        <>
            <Typography variant="h4" component="h3" className={classes.title}>
                {props.name}
            </Typography>

            <ButtonGroup
                className={classes.divider}
                color="primary"
                variant="contained"
            >
                <Button onClick={getSessions}>
                    <AutorenewRoundedIcon />
                </Button>
                <Button variant="outlined" onClick={handleSortElement}>
                    {sortElement === 12 ? (
                        <AppsRoundedIcon />
                    ) : (
                        <ReorderRoundedIcon />
                    )}
                </Button>
            </ButtonGroup>

            <LayoutContainer>
                <Grid container spacing={2}>
                    {sessions.map((session) => (
                        <Grid item xs={sortElement} key={item.id}>
                            <Card
                                className={classes.card}
                                raised={session.id === hover ? true : false}
                                onMouseEnter={() => onMouseEnter(session.id)}
                                onMouseLeave={onMouseLeave}
                                onClick={() => handleSelectSession(session)}
                            >
                                <CardContent>
                                    <Typography>{session.name}</Typography>
                                    <Typography>
                                        {session.isActive
                                            ? "Активна"
                                            : "Неактивна"}
                                    </Typography>
                                </CardContent>
                            </Card>
                        </Grid>
                    ))}
                </Grid>
            </LayoutContainer>
        </>
    )
}

Sessions.propTypes = {
    sessions: PropTypes.array.isRequired,
    selectSession: PropTypes.func.isRequired,
    getSessions: PropTypes.func.isRequired,
    redirect: PropTypes.func.isRequired,
}

export default Sessions
