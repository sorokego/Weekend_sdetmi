import React, { useState } from "react"
import { useLocation } from "react-router-dom"
import PropTypes from "prop-types"

import useStyles from "./style"
import {
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
    ListItemAvatar,
    Typography,
} from "@material-ui/core"

const Aside = (props) => {
    const classes = useStyles()
    const { redirect, routers } = props
    const [selectedRoute, setSelectedRoute] = useState(0)

    const location = useLocation()

    const handleSelect = (route) => {
        setSelectedRoute(route)
        redirect(route.path)
    }
    return (
        <aside className={classes.root}>
            <List component="nav" disablePadding>
                {routers.map((route) => (
                    <ListItem
                        divider
                        key={route.id}
                        button
                        dense
                        selected={
                            selectedRoute === route ||
                            location.pathname === route.path
                        }
                        onClick={() => handleSelect(route)}
                    >
                        <ListItemIcon>
                            <route.image
                                fontSize="small"
                                color={
                                    location.pathname === route.path
                                        ? "primary"
                                        : "inherit"
                                }
                            />
                        </ListItemIcon>
                        <ListItemText primary={route.name} />
                    </ListItem>
                ))}
            </List>
        </aside>
    )
}

Aside.propTypes = {
    redirect: PropTypes.func.isRequired,
    routers: PropTypes.array.isRequired,
}

export default Aside
