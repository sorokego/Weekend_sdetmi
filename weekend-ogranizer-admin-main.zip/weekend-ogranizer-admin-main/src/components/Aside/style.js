import { makeStyles } from "@material-ui/core"

const useStyles = makeStyles((theme) => ({
    root: {
        borderRight: `1px solid ${theme.palette.divider}`,
        position: "static",
    },
    title: {
        marginBottom: theme.spacing(2),
        borderBottom: "1px solid black",
        textAlign: "center",
    },

    // adminPanel: {
    //     display: "flex",
    //     flexDirection: "column",
    //     flexGrow: 1,
    //     overflowY: "scroll",
    //     // marginLeft: `${drawerWidth}px`,
    //     padding: theme.spacing(2),
    // },

    // large: {
    //     width: theme.spacing(5),
    //     height: theme.spacing(5),
    //     margin: theme.spacing(0, 1),
    // },

    // header: {
    //     // marginLeft: `${drawerWidth}px`,
    // },
}))

export default useStyles
