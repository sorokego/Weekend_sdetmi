import React, { useState, useEffect, useLayoutEffect } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import {
    Button,
    Card,
    CardContent,
    Divider,
    Grid,
    Typography,
    ButtonGroup,
} from "@material-ui/core"
import NewTag from "components/Tag/NewTag"
import LayoutContainer from "containers/LayoutContainer"

import AutorenewRoundedIcon from "@material-ui/icons/AutorenewRounded"
import AddCircleRoundedIcon from "@material-ui/icons/AddCircleRounded"
import AppsRoundedIcon from "@material-ui/icons/AppsRounded"
import ReorderRoundedIcon from "@material-ui/icons/ReorderRounded"

const Tags = (props) => {
    const {
        newTag,

        tags,

        selectTag,
        getTags,
        redirect,
        addTag,
        openModal,
        closeModal,
    } = props

    const classes = useStyles()
    const [hover, setHover] = useState(false)
    const [sortElement, setSortElement] = useState(4)

    const handleSortElement = () => {
        const newSortElement = sortElement === 4 ? 12 : 4
        setSortElement(newSortElement)
    }

    useLayoutEffect(() => {
        getTags()
    }, [])

    const handleSelectTag = (role) => {
        const { id } = role
        selectTag(id)
        redirect(`/tags/${id}`)
    }

    const onMouseEnter = (id) => {
        setHover(id)
    }
    const onMouseLeave = () => {
        setHover(false)
    }

    return (
        <>
            <Typography variant="h4" component="h3" className={classes.title}>
                {props.name}
            </Typography>

            <ButtonGroup
                className={classes.divider}
                color="primary"
                variant="contained"
            >
                <Button onClick={openModal}>
                    <AddCircleRoundedIcon />
                </Button>
                <Button onClick={getTags}>
                    <AutorenewRoundedIcon />
                </Button>
                <Button variant="outlined" onClick={handleSortElement}>
                    {sortElement === 12 ? (
                        <AppsRoundedIcon />
                    ) : (
                        <ReorderRoundedIcon />
                    )}
                </Button>
            </ButtonGroup>

            <LayoutContainer>
                <Grid container spacing={2}>
                    {tags.map((item) => (
                        <Grid item xs={sortElement} key={item.id}>
                            <Card
                                className={classes.card}
                                raised={item.id === hover ? true : false}
                                onMouseEnter={() => onMouseEnter(item.id)}
                                onMouseLeave={onMouseLeave}
                                onClick={() => handleSelectTag(item)}
                            >
                                <CardContent>
                                    <Typography>{item.name}</Typography>
                                    <Typography>
                                        {item.isActive
                                            ? "Активна"
                                            : "Неактивна"}
                                    </Typography>
                                </CardContent>
                            </Card>
                        </Grid>
                    ))}
                </Grid>
            </LayoutContainer>
            <NewTag newTag={newTag} addTag={addTag} closeModal={closeModal} />
        </>
    )
}

Tags.propTypes = {}

export default Tags
