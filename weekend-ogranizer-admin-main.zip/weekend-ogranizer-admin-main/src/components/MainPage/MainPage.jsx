import React from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import { Button, Typography } from "@material-ui/core"

const MainPage = (props) => {
    const classes = useStyles()
    const { logout } = props

    return (
        <div>
            <Typography> {props.name}</Typography>
            <Button variant="contained" color="primary" onClick={logout}>
                Выход
            </Button>
        </div>
    )
}

MainPage.propTypes = {}

export default MainPage
