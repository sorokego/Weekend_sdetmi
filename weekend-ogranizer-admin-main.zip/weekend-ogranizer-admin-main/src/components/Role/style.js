import { makeStyles } from "@material-ui/core"

const useStyles = makeStyles((theme) => ({
    root: {},
    title: {
        marginBottom: theme.spacing(2),
    },
    inputGroup: {
        display: "flex",
        "& > *:not(:last-child)": {
            marginRight: theme.spacing(2),
        },
    },
    divider: {
        marginBottom: theme.spacing(2),
    },
    input: {
        marginBottom: theme.spacing(2),
    },

    buttonGroup: {
        display: "flex",
        justifyContent: "space-between",
    },
}))

export default useStyles
