import React, { useEffect, useLayoutEffect, useState } from "react"
import PropTypes from "prop-types"
import RoleForm from "./RoleForm"
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
} from "@material-ui/core"
import useStyles from "./style"
import DialogWindowLayout from "../Layout/DialogWindowLayout"

const initialState = {
    name: "",
    isActive: true,
}

const NewRole = (props) => {
    const classes = useStyles()
    const { newRole, addRole, closeModal } = props

    useLayoutEffect(() => {
        setData({ ...data, ...initialState })
    }, [])

    const [data, setData] = useState(initialState)

    const handleChangeData = (event) => {
        const { id, value } = event.target
        setData({ ...data, [id]: value })
    }

    const handleChangeActive = (event) => {
        const { value } = event.target
        setData({ ...data, isActive: value })
    }

    const handleSaveRole = () => {
        addRole({ ...data })
    }

    const handleLoadImage = () => {}
    const handleClearImage = () => {}

    return (
        <DialogWindowLayout
            isOpen={newRole}
            closeModal={closeModal}
            name={data.name}
            onSave={handleSaveRole}
            type="role"
        >
            <RoleForm
                data={data}
                newRole={newRole}
                handleSaveRole={handleSaveRole}
                handleChangeData={handleChangeData}
                handleChangeActive={handleChangeActive}
                handleLoadImage={handleLoadImage}
                handleClearImage={handleClearImage}
            />
        </DialogWindowLayout>
    )
}

NewRole.propTypes = {}

export default NewRole
