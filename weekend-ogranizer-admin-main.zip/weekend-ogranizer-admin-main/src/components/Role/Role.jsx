import React, { useState, useLayoutEffect, useEffect } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import { Divider, Typography, Button } from "@material-ui/core"
import RoleForm from "./RoleForm"

const initialState = {
    name: "",
    isActive: true,
}

const statusDict = [
    { id: 1, value: true, name: "Активен" },
    { id: 2, value: false, name: "Неактивен" },
]

const Role = (props) => {
    const classes = useStyles()
    const {
        newRole, //bool
        loaded, //bool
        selectedRole, //Obj
        selectedRoleId, //int
        selectRole, //func
        modifyRole, //func
        getRoleById, //func
        deleteRole, //func
        redirect, //func
    } = props

    const [data, setData] = useState(initialState)

    useLayoutEffect(() => {
        getRoleById(selectedRoleId || props.match.params.id)
    }, [])

    useLayoutEffect(() => {
        setData({ ...data, ...selectedRole })
    }, [loaded])

    const handleDeleteRole = () => {
        deleteRole(selectedRole.id)
        redirect("/roles")
    }

    const handleChangeData = (event) => {
        const { id, value } = event.target
        setData({ ...data, [id]: value })
    }

    const validate = () => {
        if (data.name.length > 0) return true

        return false
    }
    const handleSaveRole = () => {
        const validateResult = validate()

        if (!validateResult) return

        modifyRole({
            name: data.name,
            isActive: data.isActive,
            id: selectedRole.id,
        })

        redirect(`/roles`)
    }

    const handleCancel = () => {
        selectRole({})
        redirect("/roles")
    }

    const handleChangeActive = (e) => {
        setData({ ...data, isActive: e.target.value })
    }

    return (
        <>
            <Typography component="h3" variant="h4" className={classes.title}>
                {props.name}: {data.name}
            </Typography>

            <Divider className={classes.divider} />

            <RoleForm
                data={data}
                newRole={newRole}
                selectedRole={selectedRole}
                handleChangeActive={handleChangeActive}
                handleChangeData={handleChangeData}
            />

            <div className={classes.buttonGroup}>
                <Button
                    variant="contained"
                    color="secondary"
                    onClick={handleCancel}
                >
                    Назад
                </Button>

                <Button
                    variant="contained"
                    color="secondary"
                    onClick={handleDeleteRole}
                >
                    Удалить
                </Button>
                <Button
                    variant="contained"
                    color="primary"
                    onClick={handleSaveRole}
                >
                    Сохранить
                </Button>
            </div>
        </>
    )
}

Role.propTypes = {
    newRole: PropTypes.bool.isRequired,
}

export default Role
