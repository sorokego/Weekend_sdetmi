import React from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import { TextField, Typography, MenuItem } from "@material-ui/core"

const statusDict = [
    { id: 1, value: true, name: "Активен" },
    { id: 2, value: false, name: "Неактивен" },
]

const RoleForm = (props) => {
    const classes = useStyles()
    const {
        data,
        newRole,
        handleChangeActive,
        handleChangeData,
        selectedRole,
    } = props

    return (
        <>
            <TextField
                label="Имя"
                id="name"
                className={classes.input}
                variant="outlined"
                value={data.name}
                size="small"
                onChange={handleChangeData}
                error={data.name === "" ? true : false}
                helperText={
                    data.name === ""
                        ? "Имя должно быть заполнено"
                        : "Укажите имя роли"
                }
            />
            {!newRole && selectedRole !== undefined ? (
                <>
                    <Typography variant="body1" color="textSecondary">
                        Создана: {selectedRole.createdAt}
                    </Typography>
                    <Typography variant="body1" color="textSecondary">
                        Изменена: {selectedRole.updatedAt}
                    </Typography>
                    <Typography variant="body1" color="textSecondary">
                        Удалена: {selectedRole.deletedAt}
                    </Typography>
                </>
            ) : null}
            <div className={classes.inputGroup}>
                <TextField
                    className={classes.input}
                    size="small"
                    margin="dense"
                    label="Статус"
                    variant="outlined"
                    select
                    value={data.isActive}
                    onChange={handleChangeActive}
                    helperText="Выберите статус"
                >
                    {statusDict.map((item) => (
                        <MenuItem key={item.id} value={item.value}>
                            {item.name}
                        </MenuItem>
                    ))}
                </TextField>
            </div>
        </>
    )
}

RoleForm.propTypes = {}

export default RoleForm
