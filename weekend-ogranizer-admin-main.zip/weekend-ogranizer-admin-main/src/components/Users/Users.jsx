import React, { useState, useLayoutEffect, useEffect } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import {
    Button,
    ButtonGroup,
    Card,
    CardContent,
    Divider,
    Grid,
    Typography,
} from "@material-ui/core"
import NewUser from "components/User/NewUser"
import LayoutContainer from "containers/LayoutContainer"

import AutorenewRoundedIcon from "@material-ui/icons/AutorenewRounded"
import AddCircleRoundedIcon from "@material-ui/icons/AddCircleRounded"
import AppsRoundedIcon from "@material-ui/icons/AppsRounded"
import ReorderRoundedIcon from "@material-ui/icons/ReorderRounded"

const Users = (props) => {
    const {
        newUser,

        users,
        roles,

        addUser,
        getUsers,
        redirect,
        selectUser,
        openModal,
        closeModal,
    } = props
    const classes = useStyles()

    const [hover, setHover] = useState(false)
    const [sortElement, setSortElement] = useState(4)

    const handleSortElement = () => {
        const newSortElement = sortElement === 4 ? 12 : 4
        setSortElement(newSortElement)
    }

    useLayoutEffect(() => {
        getUsers()
    }, [])

    const handleSelectUser = (user) => {
        selectUser(user)
        redirect(`/users/${user.id}`)
    }

    const onMouseEnter = (id) => {
        setHover(id)
    }
    const onMouseLeave = () => {
        setHover(false)
    }

    return (
        <>
            <Typography component="h2" variant="h4" className={classes.title}>
                {props.name}
            </Typography>

            <ButtonGroup
                className={classes.divider}
                color="primary"
                variant="contained"
            >
                <Button onClick={openModal}>
                    <AddCircleRoundedIcon />
                </Button>
                <Button onClick={getUsers}>
                    <AutorenewRoundedIcon />
                </Button>
                <Button variant="outlined" onClick={handleSortElement}>
                    {sortElement === 12 ? (
                        <AppsRoundedIcon />
                    ) : (
                        <ReorderRoundedIcon />
                    )}
                </Button>
            </ButtonGroup>

            <LayoutContainer>
                {users.length === 0 ? (
                    <Typography variant="h4" compoent="h3">
                        Список пуст
                    </Typography>
                ) : (
                    <Grid container spacing={2}>
                        {users.map((user) => (
                            <Grid
                                item
                                xs={sortElement}
                                key={user.id}
                                onClick={() => handleSelectUser(user)}
                            >
                                <Card
                                    className={classes.userCard}
                                    raised={user.id === hover ? true : false}
                                    onMouseEnter={() => onMouseEnter(user.id)}
                                    onMouseLeave={onMouseLeave}
                                >
                                    <CardContent>
                                        <Typography>id: {user.id}</Typography>
                                        <Typography>
                                            Имя: {user.firstName}{" "}
                                            {user.lastName}
                                        </Typography>
                                        <Typography>
                                            Статус:
                                            {user.status
                                                ? "Активен"
                                                : "Неактивен"}
                                        </Typography>
                                        <Typography>
                                            Почта: {user.email}
                                        </Typography>
                                        <Typography>
                                            Права: {user.Role.name}
                                        </Typography>
                                        {user.deletedAt === null ? null : (
                                            <Typography>Удален</Typography>
                                        )}
                                    </CardContent>
                                </Card>
                            </Grid>
                        ))}
                    </Grid>
                )}
            </LayoutContainer>
            <NewUser
                addUser={addUser}
                newUser={newUser}
                roles={roles}
                closeModal={closeModal}
            />
        </>
    )
}

Users.propTypes = {
    loaded: PropTypes.bool.isRequired,
    newUser: PropTypes.bool.isRequired,

    users: PropTypes.array.isRequired,
    roles: PropTypes.array.isRequired,

    addUser: PropTypes.func.isRequired,
    getUsers: PropTypes.func.isRequired,
    getUserById: PropTypes.func.isRequired,
    redirect: PropTypes.func.isRequired,
    init: PropTypes.func.isRequired,
    getRoles: PropTypes.func.isRequired,
    selectUser: PropTypes.func.isRequired,
    openModal: PropTypes.func.isRequired,
    closeModal: PropTypes.func.isRequired,
}

export default Users
