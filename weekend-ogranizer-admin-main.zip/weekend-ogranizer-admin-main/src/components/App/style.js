import { makeStyles } from "@material-ui/core"

const useStyles = makeStyles((theme) => ({
    root: {},
    wrapper: {
        display: "flex",
        flexGrow: 1,
    },

    container: {
        paddingTop: theme.spacing(2),
        paddingBottom: theme.spacing(2),
        flexGrow: 1,
        display: "flex",
        flexDirection: "column",
    },
    main: {
        display: "flex",
        flexDirection: "column",
        flexGrow: 1,
    },
    // adminPanel: {
    //     display: "flex",
    //     flexDirection: "column",
    //     flexGrow: 1,
    //     overflowY: "scroll",
    //     // marginLeft: `${drawerWidth}px`,
    //     padding: theme.spacing(2),
    // },

    // large: {
    //     width: theme.spacing(5),
    //     height: theme.spacing(5),
    //     margin: theme.spacing(0, 1),
    // },

    // header: {
    //     // marginLeft: `${drawerWidth}px`,
    // },
}))

export default useStyles
