import React, { useState, useLayoutEffect, useEffect } from "react"
import PropTypes from "prop-types"
import { Container, LinearProgress } from "@material-ui/core"
import useStyles from "./style"
import Header from "components/Header/Header"
import LoginPage from "components/LoginPage/LoginPage"
import Aside from "components/Aside/Aside"
import Footer from "components/Footer/Footer"
import Router from "./Router"

import { useLocation } from "react-router-dom"

const App = (props) => {
    const classes = useStyles()
    const {
        loginState,
        loaded,
        globalInit,

        profile,
        progress,

        routers,
        nav,

        init,
        initProfile,
        setInitTrue,
        setInitFalse,
        handleRedirect,
        startProgress,
        login,
        logout,
    } = props

    const location = useLocation()

    const [progressState, setProgressState] = useState(0)

    useLayoutEffect(() => {
        if (!loaded) {
            init()
        }
    })

    useLayoutEffect(() => {
        setInitFalse()
        startProgress(!progress)
    }, [location.pathname])

    useLayoutEffect(() => {
        setProgressState(0)
    }, [progress])

    useLayoutEffect(() => {
        if (localStorage.token) {
            initProfile()
        }
    }, [localStorage.token])

    useEffect(() => {
        const timer = setInterval(() => {
            setProgressState((oldProgress) => {
                if (oldProgress === 100) {
                    return 100
                }
                const diff = Math.random() * 10
                return Math.min(oldProgress + diff, 100)
            })
        }, 50)

        return () => {
            clearInterval(timer)
        }
    }, [progress])

    useLayoutEffect(() => {
        if (progressState === 100) {
            setInitTrue()
        }
    }, [progressState])

    return (
        <>
            <Header
                title={!loginState ? "Авторизация" : "Панель Администратора"}
                className={classes.header}
                redirect={handleRedirect}
            />
            <LinearProgress
                variant="determinate"
                value={progressState < 100 ? progressState : null}
            />

            <div className={classes.wrapper}>
                {!localStorage.token ? (
                    <LoginPage login={login} />
                ) : (
                    <>
                        <Aside redirect={handleRedirect} routers={nav} />
                        <main className={classes.main}>
                            <Container
                                maxWidth="lg"
                                className={classes.container}
                            >
                                <Router
                                    logout={logout}
                                    routers={routers}
                                    // resetProgress={resetProgress}
                                />
                            </Container>
                        </main>
                    </>
                )}
            </div>

            <Footer />
            {/* <AlertMessageContainer /> */}
        </>
    )
}

App.propTypes = {
    init: PropTypes.func,
    handleRedirect: PropTypes.func,
    loaded: PropTypes.bool.isRequired,
    routers: PropTypes.array.isRequired,
    nav: PropTypes.array.isRequired,
}
export default App
