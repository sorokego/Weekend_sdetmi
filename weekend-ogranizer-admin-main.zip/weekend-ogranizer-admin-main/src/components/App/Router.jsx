import React, { useEffect } from "react"
import PropTypes from "prop-types"
import { Route, Switch } from "react-router-dom"

const Router = (props) => {
    const { logout, routers, resetProgress } = props

    return (
        <Switch>
            {routers.map((route) => (
                <Route
                    exact={route.notExact ? false : true}
                    key={route.id}
                    path={route.path}
                    render={(props) => (
                        <route.component
                            name={route.name}
                            {...props}
                            logout={logout}
                        />
                    )}
                />
            ))}
        </Switch>
    )
}

Router.propTypes = {
    routers: PropTypes.array.isRequired,
}

export default Router
