import React, { useState, useLayoutEffect, useEffect } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import { Button, Divider, Typography } from "@material-ui/core"

// import DefaultImg from "asset/img/noimage.png"
import CategoryForm from "./CategoryForm"
// import DefaultImg from "../../asset/img/noimage.png"
import DefaultImg from "asset/img/noimage.png"
const initialState = {
    id: null,
    name: "",
    desc: "",
    image: DefaultImg,
    isActive: true,
}

const Category = (props) => {
    const classes = useStyles()

    const {
        loaded,

        selectedCategory,
        selectedCategoryId,

        redirect,
        getCategoryById,
        modifyCategory,
        deleteCategory,
    } = props
    const [image, setImage] = useState("")

    const [data, setData] = useState(initialState)

    const handleCancel = () => {
        redirect(`/categories`)
    }

    useLayoutEffect(() => {
        getCategoryById(selectedCategoryId || props.match.params.id)
    }, [])

    useLayoutEffect(() => {
        setData({ ...data, ...selectedCategory })
    }, [loaded])

    const handleChangeStatus = (e) => {
        setData({ ...data, isActive: e.target.value })
    }

    const handleChangeData = (event) => {
        const { id, value } = event.target
        setData({ ...data, [id]: value })
    }

    const validate = () => {
        return true
    }

    const handleSaveCategory = () => {
        const validateStatus = validate()

        if (!validateStatus) return

        modifyCategory({
            ...data,
        })

        redirect(`/categories`)
    }

    const hanldeDeleteCategory = () => {
        deleteCategory(data.id)
        redirect(`/categories`)
    }

    const hanldeLoadImage = () => {}
    const handleClearImage = () => {
        setData({ ...data, image: DefaultImg })
    }

    return (
        <>
            <Typography variant="h4" component="h3" className={classes.title}>
                {props.name}: {data.name}
            </Typography>

            <Divider className={classes.divider} />

            <CategoryForm
                data={data}
                image={image}
                setImage={setImage}
                handleChangeData={handleChangeData}
                handleChangeStatus={handleChangeStatus}
                hanldeLoadImage={hanldeLoadImage}
                handleClearImage={handleClearImage}
                hanldeDeleteCategory={hanldeDeleteCategory}
            />
            <div className={classes.buttonGroup}>
                <Button
                    variant="contained"
                    color="secondary"
                    onClick={handleCancel}
                >
                    Назад
                </Button>
                <Button
                    variant="contained"
                    color="secondary"
                    onClick={hanldeDeleteCategory}
                >
                    Удалить
                </Button>

                <Button
                    variant="contained"
                    color="primary"
                    onClick={handleSaveCategory}
                >
                    Сохранить
                </Button>
            </div>
        </>
    )
}

Category.propTypes = {}

export default Category
