import React, { useState } from "react"
import PropTypes from "prop-types"
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
} from "@material-ui/core"
import DefaultImg from "asset/img/noimage.png"
import CategoryForm from "./CategoryForm"
import DialogWindowLayout from "../Layout/DialogWindowLayout"

const initialState = {
    name: "",
    isActive: true,
    image: DefaultImg,
    desc: "",
}

const NewCategory = (props) => {
    const { newCategory, closeModal, addCategory } = props
    const [image, setImage] = useState("")

    const [data, setData] = useState(initialState)

    const handleSaveCatagory = () => {
        addCategory(data)
    }

    const handleChangeData = (e) => {
        setData({ ...data, [e.target.id]: e.target.value })
    }

    const handleChangeStatus = (e) => {
        setData({ ...data, isActive: e.target.value })
    }

    const hanldeLoadImage = () => {}

    const handleClearImage = () => {
        setData({ ...data, image: DefaultImg })
    }

    return (
        <DialogWindowLayout
            isOpen={newCategory}
            closeModal={closeModal}
            name={data.name}
            onSave={handleSaveCatagory}
            type="category"
        >
            <CategoryForm
                data={data}
                image={image}
                setImage={setImage}
                handleSaveCatagory={handleSaveCatagory}
                handleChangeData={handleChangeData}
                handleChangeStatus={handleChangeStatus}
                hanldeLoadImage={hanldeLoadImage}
                handleClearImage={handleClearImage}
            />
        </DialogWindowLayout>
    )
}

NewCategory.propTypes = {}

export default NewCategory
