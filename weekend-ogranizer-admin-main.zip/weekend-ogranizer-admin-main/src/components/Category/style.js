import { makeStyles } from "@material-ui/core"

const useStyles = makeStyles((theme) => ({
    root: {},
    container: { marginBottom: theme.spacing(4) },
    title: {
        marginBottom: theme.spacing(2),
    },

    divider: {
        marginBottom: theme.spacing(2),
    },
    input: {
        marginBottom: theme.spacing(2),
    },
    inputImage: {
        display: "none",
    },
    button: {
        "&:not(:last-child)": {
            marginRight: theme.spacing(2),
        },
    },
    buttonGroup: {
        display: "flex",
        justifyContent: "space-between",
    },
    imageContainer: {
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "center",
    },
    image: {
        height: 200,
        width: "100%",
        marginBottom: theme.spacing(2),
    },
}))

export default useStyles
