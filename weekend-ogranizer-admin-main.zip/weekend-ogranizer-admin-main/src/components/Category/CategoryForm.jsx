import React, { useState } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import {
    Button,
    TextField,
    Typography,
    Grid,
    MenuItem,
    CardMedia,
} from "@material-ui/core"

const statusDict = [
    { id: 1, value: true, name: "Активен" },
    { id: 2, value: false, name: "Неактивен" },
]

const CategoryForm = (props) => {
    const classes = useStyles()
    const {
        data,
        setImage,
        image,
        handleChangeData,
        handleChangeStatus,
        // hanldeLoadImage,
        handleClearImage,
    } = props

    const [imagePreview, setImagePreview] = useState("")

    const hanldeLoadImage = (event) => {
        const file = event.target.files[0]
        setImagePreview(URL.createObjectURL(file))
        setImage(file)
    }

    return (
        <Grid container spacing={2} className={classes.container}>
            <Grid item xs={7}>
                <TextField
                    fullWidth
                    variant="outlined"
                    size="small"
                    id="name"
                    value={data.name}
                    label="Имя"
                    className={classes.input}
                    onChange={(e) => handleChangeData(e)}
                    error={data.name === "" ? true : false}
                    helperText={
                        data.name === ""
                            ? "Поле должно быть заполнено"
                            : "Введите имя категории"
                    }
                />
                <TextField
                    fullWidth
                    variant="outlined"
                    size="small"
                    id="desc"
                    value={data.desc}
                    label="Описание"
                    helperText="Введите описание категории"
                    className={classes.input}
                    onChange={(e) => handleChangeData(e)}
                />
                <TextField
                    fullWidth
                    variant="outlined"
                    size="small"
                    id="isActive"
                    label="Статус"
                    helperText="Выберите статус"
                    className={classes.input}
                    value={data.isActive}
                    onChange={(e) => handleChangeStatus(e)}
                    select
                >
                    {statusDict.map((statusItem) => (
                        <MenuItem key={statusItem.id} value={statusItem.value}>
                            {statusItem.name}
                        </MenuItem>
                    ))}
                </TextField>
            </Grid>
            <Grid item xs={5} className={classes.imageContainer}>
                <Typography
                    className={classes.title}
                    variant="body1"
                    component="h3"
                >
                    Изображение:
                </Typography>
                <CardMedia
                    image={imagePreview !== "" ? imagePreview : data.image}
                    className={classes.image}
                />
                <input
                    accept="image/*"
                    className={classes.inputImage}
                    id="contained-button-file"
                    type="file"
                    onChange={(e) => hanldeLoadImage(e)}
                />
                <label htmlFor="contained-button-file">
                    <Button
                        variant="contained"
                        color="primary"
                        className={classes.button}
                        component="span"
                        size="small"
                    >
                        Загрузить
                    </Button>
                </label>

                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.button}
                    onClick={handleClearImage}
                    size="small"
                >
                    Отчистить
                </Button>
            </Grid>
        </Grid>
    )
}

CategoryForm.propTypes = {}

export default CategoryForm
