import React, { useState, useLayoutEffect, useEffect } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import { Button, Divider, Typography } from "@material-ui/core"

import TagForm from "./TagForm"
import DefaultImg from "../../asset/img/noimage.png"

const initialState = {
    id: null,
    name: "",
    isActive: true,
}

const Tag = (props) => {
    const classes = useStyles()

    const {
        loaded,

        selectedTag,
        selectedTagId,

        redirect,
        getTagById,
        modifyTag,
        deleteTag,
    } = props

    const [data, setData] = useState(initialState)

    const handleCancel = () => {
        redirect(`/tags`)
    }

    useLayoutEffect(() => {
        getTagById(selectedTagId || props.match.params.id)
    }, [])

    useLayoutEffect(() => {
        setData({ ...data, ...selectedTag })
    }, [loaded])

    const handleChangeStatus = (e) => {
        setData({ ...data, isActive: e.target.value })
    }

    const handleChangeData = (event) => {
        const { id, value } = event.target
        setData({ ...data, [id]: value })
    }

    const validate = () => {
        return true
    }

    const handleSaveTag = () => {
        const validateStatus = validate()

        if (!validateStatus) return

        modifyTag({
            ...data,
        })

        redirect(`/tags`)
    }

    const hanldeDeleteTag = () => {
        deleteTag(data.id)
        redirect(`/tags`)
    }

    const hanldeLoadImage = () => {}
    const handleClearImage = () => {
        setData({ ...data, image: DefaultImg })
    }

    return (
        <>
            <Typography variant="h4" component="h3" className={classes.title}>
                {props.name}: {data.name}
            </Typography>

            <Divider className={classes.divider} />

            <TagForm
                data={data}
                handleChangeData={handleChangeData}
                handleChangeStatus={handleChangeStatus}
                hanldeLoadImage={hanldeLoadImage}
                handleClearImage={handleClearImage}
                hanldeDeleteTag={hanldeDeleteTag}
            />
            <div className={classes.buttonGroup}>
                <Button
                    variant="contained"
                    color="secondary"
                    onClick={handleCancel}
                >
                    Назад
                </Button>
                <Button
                    variant="contained"
                    color="secondary"
                    onClick={hanldeDeleteTag}
                >
                    Удалить
                </Button>

                <Button
                    variant="contained"
                    color="primary"
                    onClick={handleSaveTag}
                >
                    Сохранить
                </Button>
            </div>
        </>
    )
}

Tag.propTypes = {}

export default Tag
