import React, { useState } from "react"
import PropTypes from "prop-types"
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
} from "@material-ui/core"
import DefaultImg from "../../asset/img/noimage.png"
import TagForm from "./TagForm"
import DialogWindowLayout from "components/Layout/DialogWindowLayout"

const initialState = {
    name: "",
    isActive: true,
}

const NewTag = (props) => {
    const { newTag, closeModal, addTag } = props

    const [data, setData] = useState(initialState)

    const handleSaveTag = () => {
        addTag(data)
    }

    const handleChangeData = (e) => {
        setData({ ...data, [e.target.id]: e.target.value })
    }

    const handleChangeStatus = (e) => {
        setData({ ...data, isActive: e.target.value })
    }

    const hanldeLoadImage = () => {}

    const handleClearImage = () => {
        setData({ ...data, image: DefaultImg })
    }

    return (
        <DialogWindowLayout
            isOpen={newTag}
            closeModal={closeModal}
            name={data.name}
            onSave={handleSaveTag}
            type="tag"
        >
            <TagForm
                data={data}
                handleSaveTag={handleSaveTag}
                handleChangeData={handleChangeData}
                handleChangeStatus={handleChangeStatus}
                hanldeLoadImage={hanldeLoadImage}
                handleClearImage={handleClearImage}
            />
        </DialogWindowLayout>
    )
}

NewTag.propTypes = {}

export default NewTag
