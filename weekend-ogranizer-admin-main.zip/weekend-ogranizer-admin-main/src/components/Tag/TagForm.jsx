import React from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import {
    Button,
    TextField,
    Typography,
    Grid,
    MenuItem,
    CardMedia,
} from "@material-ui/core"
import DefaultImg from "../../asset/img/noimage.png"

const statusDict = [
    { id: 1, value: true, name: "Активен" },
    { id: 2, value: false, name: "Неактивен" },
]

const TagForm = (props) => {
    const classes = useStyles()
    const {
        data,
        handleChangeData,
        handleChangeStatus,
        hanldeLoadImage,
        handleClearImage,
    } = props

    return (
        <Grid container spacing={2} className={classes.container}>
            <Grid item xs={7}>
                <TextField
                    fullWidth
                    variant="outlined"
                    size="small"
                    id="name"
                    value={data.name}
                    label="Имя"
                    className={classes.input}
                    onChange={(e) => handleChangeData(e)}
                    error={data.name === "" ? true : false}
                    helperText={
                        data.name === ""
                            ? "Поле должно быть заполнено"
                            : "Введите имя тэга"
                    }
                />

                <TextField
                    fullWidth
                    variant="outlined"
                    size="small"
                    id="isActive"
                    label="Статус"
                    helperText="Выберите статус"
                    className={classes.input}
                    value={data.isActive}
                    onChange={(e) => handleChangeStatus(e)}
                    select
                >
                    {statusDict.map((statusItem) => (
                        <MenuItem key={statusItem.id} value={statusItem.value}>
                            {statusItem.name}
                        </MenuItem>
                    ))}
                </TextField>
            </Grid>
            <Grid item xs={5} className={classes.imageContainer}>
                <Typography
                    className={classes.title}
                    variant="body1"
                    component="h3"
                >
                    Изображение:
                </Typography>
                <CardMedia
                    image={data.image || DefaultImg}
                    className={classes.image}
                />
                <Button
                    variant="contained"
                    color="primary"
                    className={classes.button}
                    onClick={hanldeLoadImage}
                    size="small"
                >
                    Загрузить
                </Button>
                <Button
                    variant="contained"
                    color="secondary"
                    className={classes.button}
                    onClick={handleClearImage}
                    size="small"
                >
                    Отчистить
                </Button>
            </Grid>
        </Grid>
    )
}

TagForm.propTypes = {}

export default TagForm
