import { makeStyles } from "@material-ui/core"

const useStyles = makeStyles((theme) => ({
    root: {
        padding: ".5rem 2rem",
        alignItems: "center",
        flexDirection: "row",
        backgroundColor: "#154142",
        color: theme.palette.primary.contrastText,

        // backgroundColor: theme.palette.primary.contrastText,
        // color: "#154142",
    },
    title: {
        fontFamily: "Montserrat",
        fontWeight: "700",
        flexGrow: 1,
    },
    logo: {
        marginRight: theme.spacing(2),
        cursor: "pointer",
    },
    divider: {
        marginRight: theme.spacing(2),
    },
}))

export default useStyles
