import {
    Divider,
    Typography,
    AppBar,
    Button,
    IconButton,
} from "@material-ui/core"
import React from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import SettingsApplicationsIcon from "@material-ui/icons/SettingsApplications"
import AccountCircleIcon from "@material-ui/icons/AccountCircle"

export default function Header(props) {
    const classes = useStyles()
    const { redirect, title } = props

    const handleRedirect = () => {
        redirect("/")
    }

    return (
        <AppBar className={classes.root} color="transparent" position="sticky">
            {/* <img
                src={`/img/logo-white.png`}
                width="75"
                alt="logo"
                className={classes.logo}
                // onClick={handleRedirect}
            /> */}
            <Divider
                orientation="vertical"
                flexItem
                className={classes.divider}
            />
            <Typography variant="h4" component="h2" className={classes.title}>
                {title}
            </Typography>
            <IconButton color="inherit" onClick={() => redirect("/profile")}>
                <AccountCircleIcon fontSize="large" />
            </IconButton>
        </AppBar>
    )
}

Header.propTypes = {
    redirect: PropTypes.func,
    title: PropTypes.string.isRequired,
}
