import React from "react"
import PropTypes from "prop-types"
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
} from "@material-ui/core"

const DialogWindowLayout = (props) => {
    const { isOpen, closeModal, children, name, onSave, type } = props

    const typeDict = {
        tag: "Новый Тэг",
        user: "Новый Пользователь",
        category: "Новая категория",
        service: "Новый сервис",
        subcategory: "Новая подкатегория",
        role: "Новая Роль",
        default: "Новый элемент",
    }

    const nameDict = {
        tag: "Тэг",
        user: "Пользователь",
        category: "Категория",
        service: "Сервис",
        subcategory: "Подкатегория",
        role: "Роль",
        default: "Элемент",
    }

    return (
        <Dialog open={isOpen} onClose={closeModal} maxWidth="lg" fullWidth>
            <DialogTitle>
                {name === ""
                    ? typeDict[type] || typeDict.default
                    : `${nameDict[type]} : ${name}` || nameDict.default}
            </DialogTitle>
            <DialogContent dividers>{children}</DialogContent>
            <DialogActions>
                <Button
                    onClick={closeModal}
                    variant="contained"
                    color="secondary"
                >
                    Отмена
                </Button>
                <Button onClick={onSave} variant="contained" color="primary">
                    Сохранить
                </Button>
            </DialogActions>
        </Dialog>
    )
}

DialogWindowLayout.propTypes = {
    isOpen: PropTypes.bool.isRequired,
    closeModal: PropTypes.func.isRequired,
    name: PropTypes.string.isRequired,
    onSave: PropTypes.func.isRequired,
    type: PropTypes.string.isRequired,
}

export default DialogWindowLayout
