import React from "react"
import PropTypes from "prop-types"
import { Typography, Grid } from "@material-ui/core"
import Skeleton from "@material-ui/lab/Skeleton"

const Layout = (props) => {
    const { globalInit, children } = props
    return (
        <>
            {!globalInit ? (
                <Grid container spacing={2}>
                    {[1, 2, 3, 4].map((item) => (
                        <Grid item xs={4} key={item}>
                            <Skeleton variant="rect" width={200} height={90} />
                        </Grid>
                    ))}
                </Grid>
            ) : (
                <>{children}</>
            )}
        </>
    )
}

Layout.propTypes = {
    globalInit: PropTypes.bool.isRequired,
}

export default Layout
