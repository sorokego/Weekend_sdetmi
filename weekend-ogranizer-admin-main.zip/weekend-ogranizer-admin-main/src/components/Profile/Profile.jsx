import React, { useState, useEffect, useLayoutEffect } from "react"
import PropTypes from "prop-types"

const Profile = (props) => {
    const {
        profile,
        selectedUser,
        redirect,
        initProfile,
        modifyUser,
        logout,
    } = props

    useLayoutEffect(() => {
        initProfile(profile.id)
    }, [])

    return <div></div>
}

Profile.propTypes = {}

export default Profile
