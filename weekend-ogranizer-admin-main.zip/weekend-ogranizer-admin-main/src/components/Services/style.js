import { makeStyles } from "@material-ui/core"

const useStyles = makeStyles((theme) => ({
    title: { marginBottom: theme.spacing(2) },
    divider: { marginBottom: theme.spacing(2) },
}))

export default useStyles
