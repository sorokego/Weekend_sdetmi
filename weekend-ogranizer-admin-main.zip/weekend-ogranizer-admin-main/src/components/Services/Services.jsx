import React, { useEffect, useLayoutEffect, useState } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import ServiceList from "./ServiceList"
import {
    ButtonGroup,
    Divider,
    Typography,
    Button,
    CardContent,
    Card,
    Chip,
    Grid,
} from "@material-ui/core"

import LayoutContainer from "containers/LayoutContainer"

import AutorenewRoundedIcon from "@material-ui/icons/AutorenewRounded"
import AppsRoundedIcon from "@material-ui/icons/AppsRounded"
import ReorderRoundedIcon from "@material-ui/icons/ReorderRounded"
import AddCircleRoundedIcon from "@material-ui/icons/AddCircleRounded"

const Services = (props) => {
    const classes = useStyles()
    const {
        redirect,
        addService,
        selectService,
        getServices,
        createService,
        services,
        newSerivce,
        loaded,
    } = props
    const [sortElement, setSortElement] = useState(4)

    const handleSortElement = () => {
        const newSortElement = sortElement === 4 ? 12 : 4
        setSortElement(newSortElement)
    }

    useLayoutEffect(() => {
        getServices()
    }, [])

    const handleCreateService = () => {}

    return (
        <>
            <Typography component="h3" variant="h4" className={classes.title}>
                {props.name}
            </Typography>

            <ButtonGroup
                className={classes.divider}
                color="primary"
                variant="contained"
            >
                <Button onClick={handleCreateService}>
                    <AddCircleRoundedIcon />
                </Button>
                <Button onClick={getServices}>
                    <AutorenewRoundedIcon />
                </Button>
                <Button variant="outlined" onClick={handleSortElement}>
                    {sortElement === 12 ? (
                        <AppsRoundedIcon />
                    ) : (
                        <ReorderRoundedIcon />
                    )}
                </Button>
            </ButtonGroup>

            <LayoutContainer>
                <Grid container spacing={2}>
                    {services.map((service, idx) => (
                        <Grid item xs={sortElement} key={service.id + idx}>
                            <Card key={service.id}>
                                <CardContent>
                                    <Typography>Имя: {service.name}</Typography>
                                    <Typography>
                                        Категория: {service.Category.name}
                                    </Typography>

                                    {service.Tags.length <= 0
                                        ? null
                                        : service.Tags.map((tag) => (
                                              <Chip
                                                  label={tag.name}
                                                  color="primary"
                                                  clickable
                                                  key={tag.id}
                                              />
                                          ))}
                                </CardContent>
                            </Card>
                        </Grid>
                    ))}
                </Grid>
            </LayoutContainer>
            {/* <ServiceList
                redirect={redirect}
                services={services}
                selectService={selectService}
            /> */}
        </>
    )
}

Services.propTypes = {
    redirect: PropTypes.func.isRequired,
    getServices: PropTypes.func.isRequired,
    services: PropTypes.array.isRequired,
}

export default Services
