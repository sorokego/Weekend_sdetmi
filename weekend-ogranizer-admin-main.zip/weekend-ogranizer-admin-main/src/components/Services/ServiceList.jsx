import React from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import { List, ListItem, ListItemText } from "@material-ui/core"

const ServiceList = (props) => {
    const classes = useStyles()
    const { services, selectService, redirect } = props

    const handleSelectService = (serivce) => {
        selectService(serivce)
        redirect(`/service`)
    }
    console.log(services)

    return (
        <>
            <List>
                {services.length <= 0
                    ? null
                    : services.map((service) => (
                          <ListItem
                              button
                              key={service.id}
                              onClick={() => handleSelectService(service)}
                          >
                              <ListItemText
                                  primary={service.name}
                                  secondary={
                                      <div>
                                          <div>{service.Category.name} </div>
                                          <div>
                                              {service.isActive
                                                  ? "Активен"
                                                  : "Неактивен"}
                                          </div>
                                      </div>
                                  }
                              />
                          </ListItem>
                      ))}
            </List>
        </>
    )
}

ServiceList.propTypes = {}

export default ServiceList
