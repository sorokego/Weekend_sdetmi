import React, { useLayoutEffect, useEffect, useState } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import {
    ButtonGroup,
    Divider,
    Typography,
    Button,
    List,
    ListItem,
    ListItemAvatar,
    ListItemText,
    ListItemSecondaryAction,
    IconButton,
    Avatar,
} from "@material-ui/core"
import CommentIcon from "@material-ui/icons/Comment"
import DefaultImg from "../../asset/img/noimage.png"

import NewCategory from "components/Category/NewCategory"
import LayoutContainer from "containers/LayoutContainer"

import AutorenewRoundedIcon from "@material-ui/icons/AutorenewRounded"
import AppsRoundedIcon from "@material-ui/icons/AppsRounded"
import ReorderRoundedIcon from "@material-ui/icons/ReorderRounded"
import AddCircleRoundedIcon from "@material-ui/icons/AddCircleRounded"

const Categories = (props) => {
    const classes = useStyles()
    const {
        newCategory,

        categories,

        addCategory,
        redirect,
        getCategories,
        selectCategory,
        openModal,
        closeModal,
    } = props

    const [sortElement, setSortElement] = useState(4)

    const handleSortElement = () => {
        const newSortElement = sortElement === 4 ? 12 : 4
        setSortElement(newSortElement)
    }

    useLayoutEffect(() => {
        getCategories()
    }, [])

    const handleSelectCategory = (category) => {
        selectCategory(category.id)
        redirect(`/categories/${category.id}`)
    }

    return (
        <>
            <Typography variant="h4" component="h3" className={classes.title}>
                {props.name}
            </Typography>

            <ButtonGroup
                className={classes.divider}
                color="primary"
                variant="contained"
            >
                <Button onClick={openModal}>
                    <AddCircleRoundedIcon />
                </Button>
                <Button onClick={getCategories}>
                    <AutorenewRoundedIcon />
                </Button>
                <Button variant="outlined" onClick={handleSortElement}>
                    {sortElement === 12 ? (
                        <AppsRoundedIcon />
                    ) : (
                        <ReorderRoundedIcon />
                    )}
                </Button>
            </ButtonGroup>

            <LayoutContainer>
                {categories.length <= 0 ? (
                    <Typography variant="h4" component="h2">
                        Список Пуст
                    </Typography>
                ) : (
                    <List dense>
                        {categories.map((item) => (
                            <ListItem
                                button
                                key={item.id}
                                dense
                                divider
                                onClick={() => handleSelectCategory(item)}
                            >
                                <ListItemAvatar>
                                    <Avatar
                                        alt="category image"
                                        variant="square"
                                        image={DefaultImg}
                                        src={
                                            item.image === ""
                                                ? DefaultImg
                                                : item.image
                                        }
                                    />
                                </ListItemAvatar>
                                <ListItemText
                                    primary={
                                        <Typography>{item.name}</Typography>
                                    }
                                    secondary={`Описание ${item.isActive}`}
                                />
                            </ListItem>
                        ))}
                    </List>
                )}
            </LayoutContainer>

            <NewCategory
                newCategory={newCategory}
                closeModal={closeModal}
                addCategory={addCategory}
            />
        </>
    )
}

Categories.propTypes = {
    newCategory: PropTypes.bool.isRequired,

    categories: PropTypes.array.isRequired,

    addCategory: PropTypes.func.isRequired,
    redirect: PropTypes.func.isRequired,
    getCategories: PropTypes.func.isRequired,
    selectCategory: PropTypes.func.isRequired,
    openModal: PropTypes.func.isRequired,
    closeModal: PropTypes.func.isRequired,
}

export default Categories
