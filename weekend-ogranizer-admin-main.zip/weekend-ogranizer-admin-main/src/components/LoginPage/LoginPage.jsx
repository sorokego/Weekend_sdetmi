import React, { useState } from "react"
import PropTypes from "prop-types"
import {
    Button,
    Container,
    FormControl,
    TextField,
    Typography,
} from "@material-ui/core"
import useStyles from "./style"

const LoginPage = (props) => {
    const classes = useStyles()

    const { login } = props
    const [data, setData] = useState({ email: "", password: "" })
    // const [email, setEmail] = useState("")
    // const [password, setPassword] = useState("")

    const handleLogin = () => {
        if (data.email.length > 0 && data.password.length > 0) {
            login(data)
        }
    }

    // const handleEmail = (event) => {
    //     console.log(event.target)
    //     setEmail(event.target.value)
    // }

    // const handlePassword = (event) => {
    //     console.log(event.target)
    //     setPassword(event.target.value)
    // }

    const handleChange = (event) => {
        setData({ ...data, [event.target.name]: event.target.value })
    }

    return (
        <Container maxWidth="sm">
            <form className={classes.form} onSubmit={handleLogin}>
                <Typography
                    component="h3"
                    variant="h3"
                    className={classes.title}
                >
                    Авторизация
                </Typography>
                <TextField
                    label="Логин"
                    variant="outlined"
                    color="primary"
                    size="small"
                    name="email"
                    fullWidth
                    required
                    className={classes.textFiled}
                    value={data.email}
                    onChange={(e) => handleChange(e)}
                    error={data.email.length <= 0}
                    helperText={
                        data.email.length <= 0
                            ? "Поле не может быть пустой"
                            : "Введите почту"
                    }
                />
                <TextField
                    label="Пароль"
                    variant="outlined"
                    color="primary"
                    size="small"
                    name="password"
                    fullWidth
                    required
                    type="password"
                    className={classes.textFiled}
                    value={data.password}
                    onChange={(e) => handleChange(e)}
                    error={data.password.length <= 0}
                    helperText={
                        data.password.length <= 0
                            ? "Пароль не может быть пустым"
                            : "Введите пароль"
                    }
                />
                <Button
                    color="primary"
                    variant="contained"
                    onClick={handleLogin}
                    disabled={
                        data.password.length <= 0 || data.email.length <= 0
                    }
                >
                    Войти
                </Button>
            </form>
        </Container>
    )
}

LoginPage.propTypes = {}

export default LoginPage
