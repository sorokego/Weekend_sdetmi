import { makeStyles } from "@material-ui/core"

const useStyles = makeStyles((theme) => ({
    title: {
        marginBottom: "1rem",
    },
    form: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        width: "100%",
    },
    textFiled: {
        marginBottom: "1rem",
    },
}))

export default useStyles
