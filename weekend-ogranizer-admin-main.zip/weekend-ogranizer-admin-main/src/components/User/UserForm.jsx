import React, { useState } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import {
    Collapse,
    Grid,
    MenuItem,
    TextField,
    Typography,
} from "@material-ui/core"

const statusDict = [
    { id: 1, value: true, name: "Активен" },
    { id: 2, value: false, name: "Неактивен" },
]

const UserForm = (props) => {
    const classes = useStyles()
    const {
        newUser,
        data,
        selectedUser,
        roles,
        handleChangeActive,
        handleChangeData,
        handleChangeRole,
        showPasswordForm,
    } = props

    return (
        <Grid container spacing={2}>
            <Grid item xs={4}>
                <TextField
                    fullWidth
                    size="small"
                    id="firstName"
                    variant="outlined"
                    value={data.firstName}
                    label="Имя"
                    required
                    onChange={handleChangeData}
                    error={data.firstName === "" ? true : false}
                    helperText={
                        data.firstName === ""
                            ? "Поле не может быть пустым"
                            : "Введите имя пользователя"
                    }
                />
            </Grid>
            <Grid item xs={4}>
                <TextField
                    fullWidth
                    size="small"
                    id="lastName"
                    variant="outlined"
                    value={data.lastName}
                    label="Фамилия"
                    onChange={handleChangeData}
                />
            </Grid>
            <Grid item xs={4}>
                <TextField
                    fullWidth
                    size="small"
                    id="email"
                    variant="outlined"
                    label="Почта"
                    type="email"
                    required
                    value={data.email}
                    onChange={handleChangeData}
                    error={data.email === "" ? true : false}
                    helperText={
                        data.email === ""
                            ? "Поле не может быть пустым"
                            : "Введите почту"
                    }
                />
            </Grid>
            {roles.length > 0 ? (
                <Grid item xs={4}>
                    <TextField
                        fullWidth
                        size="small"
                        id="role"
                        variant="outlined"
                        value={data.Role ? data.Role.id : roles[0].id}
                        label="Права"
                        select
                        onChange={handleChangeRole}
                    >
                        {roles.map((roleItem) => (
                            <MenuItem value={roleItem.id} key={roleItem.id}>
                                {roleItem.name}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>
            ) : null}
            {Object.keys(data).length > 0 ? (
                <Grid item xs={4}>
                    <TextField
                        fullWidth
                        size="small"
                        id="status"
                        variant="outlined"
                        label="Статус"
                        select
                        value={data.status}
                        onChange={handleChangeActive}
                    >
                        {statusDict.map((statusItem) => (
                            <MenuItem
                                key={statusItem.id}
                                value={statusItem.value}
                            >
                                {statusItem.name}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>
            ) : null}
            <Grid item xs={12}>
                {!newUser && selectedUser !== undefined ? (
                    <>
                        <Typography variant="body1" color="textSecondary">
                            Создан: {selectedUser.createdAt}
                        </Typography>
                        <Typography variant="body1" color="textSecondary">
                            Изменен: {selectedUser.updatedAt}
                        </Typography>
                        <Typography variant="body1" color="textSecondary">
                            Удален: {selectedUser.deletedAt}
                        </Typography>
                    </>
                ) : null}
            </Grid>
            <Grid item xs={12}>
                <Collapse in={showPasswordForm || newUser}>
                    <TextField
                        fullWidth
                        size="small"
                        variant="outlined"
                        type="password"
                        required={newUser ? true : false}
                        className={classes.passwordField}
                        value={data.password}
                        id="password"
                        onChange={handleChangeData}
                        label="Пароль"
                        error={data.password === "" ? true : false}
                        helperText={
                            data.password === ""
                                ? "Поле не может быть пустым"
                                : "Введите пароль"
                        }
                    />
                    {/* <TextField
                        fullWidth
                        size="small"
                        variant="outlined"
                        type="password"
                        required={newUser ? true : false}
                        className={classes.passwordField}
                        value={rePassword}
                        id="repass"
                        onChange={handleChangePassword}
                        label="Повторить пароль"
                        error={newUser && rePassword.length <= 0 ? true : false}
                        helperText={
                            rePassword.length <= 0
                                ? "Поле не может быть пустым"
                                : "Введите пароль"
                        }
                    /> */}
                </Collapse>
            </Grid>
        </Grid>
    )
}

UserForm.propTypes = {}

export default UserForm
