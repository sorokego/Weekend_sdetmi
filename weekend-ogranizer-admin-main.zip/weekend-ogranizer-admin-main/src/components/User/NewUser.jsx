import React, { useEffect, useLayoutEffect, useState } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import {
    Button,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
} from "@material-ui/core"
import UserForm from "./UserForm"
import DialogWindowLayout from "../Layout/DialogWindowLayout"

const initialState = {
    firstName: "",
    lastName: "",
    status: true,
    email: "",
    Role: { name: "", id: 1 },
    RoleId: null,
    password: "",
}

const NewUser = (props) => {
    const classes = useStyles()
    const { newUser, addUser, closeModal, roles } = props

    const [data, setData] = useState(initialState)

    useLayoutEffect(() => {
        setData({
            ...data,
            ...initialState,
        })
    }, [])

    const handleChangeData = (event) => {
        const { value, id } = event.target
        setData({ ...data, [id]: value })
    }

    const handleChangeActive = (event) => {
        const { value } = event.target
        setData({ ...data, isActive: value })
    }

    const handleChangeRole = (event) => {
        const { value } = event.target
        const newRole = roles.find((item) => item.id === value)
        setData({ ...data, Role: newRole, RoleId: value })
    }

    const handleSaveUser = () => {
        addUser({ ...data })
    }

    const handleLoadImage = () => {}
    const handleClearImage = () => {}

    return (
        <DialogWindowLayout
            isOpen={newUser}
            closeModal={closeModal}
            name={data.firstName}
            onSave={handleSaveUser}
            type="user"
        >
            <UserForm
                data={data}
                newUser={newUser}
                roles={roles}
                handleChangeRole={handleChangeRole}
                handleChangeData={handleChangeData}
                handleChangeActive={handleChangeActive}
                handleLoadImage={handleLoadImage}
                handleClearImage={handleClearImage}
            />
        </DialogWindowLayout>
    )
}

NewUser.propTypes = {}

export default NewUser
