import React, { useState, useLayoutEffect, useEffect } from "react"
import PropTypes from "prop-types"
import useStyles from "./style"
import { Button, Typography, Divider } from "@material-ui/core"
import UserForm from "./UserForm"

const initialState = {
    firstName: "",
    lastName: "",
    status: true,
    email: "",
    Role: { name: "", id: 1 },
    RoleId: null,
    password: "",
}

const User = (props) => {
    const classes = useStyles()
    const {
        loaded,
        newUser,

        selectedUser,
        selectedUserId,

        roles,

        redirect,
        modifyUser,
        deleteUser,
        selectUser,
        getUserById,
        getRoles,
    } = props

    const [showPasswordForm, setShowPasswordForm] = useState(false)

    const [data, setData] = useState(initialState)

    //подгрузка пользователя
    useLayoutEffect(() => {
        getUserById(selectedUserId || props.match.params.id)
        getRoles()
    }, [])

    //переход на конт ролируемые компоненты
    useEffect(() => {
        setData({ ...initialState, ...selectedUser })
    }, [loaded])

    const handleChangeActive = (e) => {
        setData({ ...data, status: e.target.value })
    }

    const handleRedirect = () => {
        redirect("/users")
    }

    const handleDeleteUser = () => {
        deleteUser(data.id)
        redirect("/users")
    }
    const handleChangeRole = (e) => {
        const result = roles.find((item) => item.id === e.target.value)
        setData({ ...data, Role: result, RoleId: result.id })
    }

    const handleChangeData = (e) => {
        setData({ ...data, [e.target.id]: e.target.value })
    }

    const handleShowPasswordForm = () => {
        setShowPasswordForm(!showPasswordForm)
    }

    const validate = () => {
        const { firstName, email, password } = data
        if (firstName.length > 0 && email.length > 0 && password.length > 0) {
            return true
        } else {
            return false
        }
    }

    const handleSave = () => {
        const validateStatus = validate()
        if (!validateStatus) return

        modifyUser({
            ...data,
            password: data.password,
        })

        redirect("/users")
    }

    if (Object.keys(selectedUser).length <= 0) {
        return <Typography>Загрузка</Typography>
    }

    return (
        <>
            <Typography
                variant="h4"
                component="h3"
                className={classes.blockTitle}
            >
                {props.name}: {data.firstName} {data.lastName}
            </Typography>
            <UserForm
                data={data}
                newUser={newUser}
                selectedUser={selectedUser}
                handleSave={handleSave}
                roles={roles}
                handleChangeActive={handleChangeActive}
                handleChangeData={handleChangeData}
                handleChangeRole={handleChangeRole}
                showPasswordForm={showPasswordForm}
            />
            <Divider className={classes.divider} />
            <div className={classes.buttonGroup}>
                <Button
                    variant="contained"
                    color="secondary"
                    onClick={handleRedirect}
                >
                    Отмена
                </Button>

                <Button
                    variant="contained"
                    color="secondary"
                    onClick={handleDeleteUser}
                >
                    Удалить
                </Button>
                <Button
                    variant="contained"
                    color={showPasswordForm ? "primary" : "default"}
                    onClick={handleShowPasswordForm}
                >
                    Смена пароля
                </Button>
                <Button
                    variant="contained"
                    color="primary"
                    onClick={handleSave}
                >
                    Сохранить
                </Button>
            </div>
        </>
    )
}

User.propTypes = {}

export default User
