import { makeStyles } from "@material-ui/core"

const useStyles = makeStyles((theme) => ({
    root: {},
    paper: {
        padding: theme.spacing(2, 1),
    },
    buttonGroup: {
        display: "flex",
        justifyContent: "space-between",
    },
    divider: {
        margin: theme.spacing(1, 0),
    },
    blockTitle: {
        margin: theme.spacing(0, 0, 2, 0),
    },
    passwordField: {
        marginBottom: theme.spacing(2),
    },
}))

export default useStyles
