import {
    GET_SERVICES,
    GET_SERVICE_BY_ID,
    DELETE_SERVICE,
    ADD_SERVICE,
    MODIFY_SERVICE,
} from "actions/services"

import { startProgressAction } from "actions/init"

import axios from "axios"

export const servicesMiddleWare = (store) => (next) => async (action) => {
    if (action.type === GET_SERVICE_BY_ID) {
        const getServiceById = async (id) => {
            try {
                const result = await axios.get(`${SERVER}/api/services/${id}`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await getServiceById(action.payload)
        action.payload = {
            ...result,
        }
    }
    if (action.type === ADD_SERVICE) {
        const addService = async (service) => {
            try {
                const result = await axios.post(
                    `${SERVER}/api/services`,
                    service,
                    {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "App-Type": "adminPanel",
                        },
                    }
                )
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await addService(action.payload)
        action.payload = {
            ...result,
        }
    }
    if (action.type === GET_SERVICES) {
        const getServices = async () => {
            try {
                const result = await axios.get(`${SERVER}/api/services`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await getServices()
        action.payload = {
            result,
        }
        store.dispatch(startProgressAction())
    }

    if (action.type === DELETE_SERVICE) {
        const deleteServiceById = async (id) => {
            try {
                const result = await axios.delete(
                    `${SERVER}/api/services/${id}`,
                    {
                        headers: {
                            "Content-Type": "application/json",
                            "App-Type": "adminPanel",
                        },
                    }
                )
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await deleteServiceById(action.payload)
        action.payload = {
            ...result,
        }
    }

    if (action.type === MODIFY_SERVICE) {
        const modifyService = async (service) => {
            try {
                const result = await axios.put(
                    `${SERVER}/api/services/${service.id}`,
                    { ...service },
                    {
                        headers: {
                            "Content-Type": "application/json",
                            "App-Type": "adminPanel",
                        },
                    }
                )
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await modifyService(action.payload)
        action.payload = {
            result,
        }
    }

    return next(action)
}
