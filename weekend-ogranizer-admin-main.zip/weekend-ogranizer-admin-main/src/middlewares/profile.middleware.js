import { LOGIN, LOGOUT, INIT_PROFILE } from "actions/profile"

import axios from "axios"

export const profileMiddleWare = (store) => (next) => async (action) => {
    if (action.type === LOGIN) {
        const login = async (user) => {
            try {
                const result = await axios.post(`${SERVER}/auth/login`, user, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                localStorage.setItem("token", result.data.token)
                return {
                    token: result.data.token,
                    profile: result.data.profile,
                }
            } catch (error) {
                console.log(error.message, "error")
            }
        }
        const result = await login(action.payload)
        action.payload = {
            ...result,
        }
    }

    // if (action.type === LOGOUT) {
    //     const logout = async () => {
    //         try {
    //             const result = await axios.get(`${SERVER}/auth/logout`, {
    //                 method: "GET",
    //                 headers: {
    //                     "Content-Type": "application/json",
    //                     "App-Type": "adminPanel",
    //                 },
    //             })
    //             localStorage.removeItem("token")

    //             return result.data
    //         } catch (error) {
    //             console.log(error, "error")
    //         }
    //     }
    //     const result = await logout()
    //     action.payload = {
    //         ...result,
    //     }
    // }

    if (action.type === INIT_PROFILE) {
        const init = async (token) => {
            try {
                const result = await axios.get(`${SERVER}/auth/user`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                        Authorization: `Bearer ${token}`,
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.message, "error")
            }
        }
        const token = localStorage.token

        const result = await init(token)
        action.payload = {
            ...result.profile,
        }
    }

    return next(action)
}
