import axios from "axios"

import {
    GET_SESSIONS,
    GET_SESSION_BY_ID,
    MODIFY_SESSION,
} from "actions/sessions"

import { startProgressAction } from "actions/init"

export const sessionsMiddleWare = (store) => (next) => async (action) => {
    if (action.type === GET_SESSION_BY_ID) {
        const getSessionById = async (id) => {
            try {
                const result = await axios.get(`${SERVER}/api/sessions/${id}`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await getSessionById(action.payload)
        action.payload = {
            ...result,
        }
    }

    if (action.type === GET_SESSIONS) {
        const getSessions = async () => {
            try {
                const result = await axios.get(`${SERVER}/api/sessions`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await getSessions()
        action.payload = {
            result,
        }
        store.dispatch(startProgressAction(false))
    }

    if (action.type === MODIFY_SESSION) {
        const modifySession = async (session) => {
            try {
                const result = await axios.put(
                    `${SERVER}/api/sessions/${session.id}`,
                    { ...session },
                    {
                        headers: {
                            "Content-Type": "application/json",
                            "App-Type": "adminPanel",
                        },
                    }
                )
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await modifySession(action.payload)
        action.payload = {
            result,
        }
    }

    return next(action)
}
