import axios from "axios"

import {
    GET_CATEGORIES,
    GET_CATEGORY_BY_ID,
    DELETE_CATEGORY,
    MODIFY_CATEGORY,
    ADD_CATEGORY,
} from "actions/categories"

import { startProgressAction } from "actions/init"

export const categoriesMiddleWare = (store) => (next) => async (action) => {
    if (action.type === GET_CATEGORY_BY_ID) {
        const getCategoryById = async (id) => {
            try {
                const result = await axios.get(
                    `${SERVER}/api/categories/${id}`,
                    {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/json",
                            "App-Type": "adminPanel",
                        },
                    }
                )
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await getCategoryById(action.payload)
        action.payload = {
            ...result,
        }
    }

    if (action.type === GET_CATEGORIES) {
        const getCategories = async () => {
            try {
                const result = await axios.get(`${SERVER}/api/categories`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await getCategories()
        action.payload = {
            result,
        }
        store.dispatch(startProgressAction())
    }

    if (action.type === ADD_CATEGORY) {
        const addCategory = async (category) => {
            try {
                const result = await axios.post(
                    `${SERVER}/api/categories`,
                    category,
                    {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "App-Type": "adminPanel",
                        },
                    }
                )
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await addCategory(action.payload)
        action.payload = {
            ...result,
        }
    }

    if (action.type === DELETE_CATEGORY) {
        const deleteCategoryById = async (id) => {
            try {
                const result = await axios.delete(
                    `${SERVER}/api/categories/${id}`,
                    {
                        headers: {
                            "Content-Type": "application/json",
                            "App-Type": "adminPanel",
                        },
                    }
                )
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await deleteCategoryById(action.payload)
        action.payload = {
            result,
        }
    }

    if (action.type === MODIFY_CATEGORY) {
        const modifyCategory = async (category) => {
            try {
                const result = await axios.put(
                    `${SERVER}/api/categories/${category.id}`,
                    { ...category },
                    {
                        headers: {
                            "Content-Type": "application/json",
                            "App-Type": "adminPanel",
                        },
                    }
                )
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await modifyCategory(action.payload)
        action.payload = {
            result,
        }
    }

    return next(action)
}
