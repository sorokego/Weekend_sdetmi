import {
    GET_ROLES,
    GET_ROLE_BY_ID,
    DELETE_ROLE,
    ADD_ROLE,
    MODIFY_ROLE,
} from "actions/roles"

import { startProgressAction } from "actions/init"

import axios from "axios"

export const rolesMiddleWare = (store) => (next) => async (action) => {
    if (action.type === GET_ROLE_BY_ID) {
        const getRoleById = async (id) => {
            try {
                const result = await axios.get(`${SERVER}/api/roles/${id}`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await getRoleById(action.payload)
        action.payload = {
            ...result,
        }
    }
    if (action.type === ADD_ROLE) {
        const addRole = async (role) => {
            try {
                const result = await axios.post(`${SERVER}/api/roles`, role, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await addRole(action.payload)
        action.payload = {
            ...result,
        }
    }
    if (action.type === GET_ROLES) {
        const getRoles = async () => {
            try {
                const result = await axios.get(`${SERVER}/api/roles`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await getRoles()
        action.payload = {
            result,
        }
        store.dispatch(startProgressAction())
    }

    if (action.type === DELETE_ROLE) {
        const deleteRoleById = async (id) => {
            try {
                const result = await axios.delete(`${SERVER}/api/roles/${id}`, {
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await deleteRoleById(action.payload)
        action.payload = {
            result,
        }
    }

    if (action.type === MODIFY_ROLE) {
        const modifyRole = async (role) => {
            try {
                const result = await axios.put(
                    `${SERVER}/api/roles/${role.id}`,
                    { ...role },
                    {
                        headers: {
                            "Content-Type": "application/json",
                            "App-Type": "adminPanel",
                        },
                    }
                )
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await modifyRole(action.payload)
        action.payload = {
            result,
        }
    }

    return next(action)
}
