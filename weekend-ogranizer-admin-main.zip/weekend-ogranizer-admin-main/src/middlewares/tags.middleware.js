import axios from "axios"

import {
    GET_TAGS,
    GET_TAG_BY_ID,
    DELETE_TAG,
    MODIFY_TAG,
    ADD_TAG,
} from "actions/tags"

import { startProgressAction } from "actions/init"

export const tagsMiddleWare = (store) => (next) => async (action) => {
    if (action.type === GET_TAG_BY_ID) {
        const getTagById = async (id) => {
            try {
                const result = await axios.get(`${SERVER}/api/tags/${id}`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await getTagById(action.payload)
        action.payload = {
            ...result,
        }
    }

    if (action.type === GET_TAGS) {
        const getTags = async () => {
            try {
                const result = await axios.get(`${SERVER}/api/tags`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await getTags()
        action.payload = {
            result,
        }
        store.dispatch(startProgressAction(false))
    }

    if (action.type === ADD_TAG) {
        const addTag = async (tag) => {
            try {
                const result = await axios.post(`${SERVER}/api/tags`, tag, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await addTag(action.payload)
        action.payload = {
            ...result,
        }
    }

    if (action.type === DELETE_TAG) {
        const deleteTagById = async (id) => {
            try {
                const result = await axios.delete(`${SERVER}/api/tags/${id}`, {
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await deleteTagById(action.payload)
        action.payload = {
            result,
        }
    }

    if (action.type === MODIFY_TAG) {
        const modifyTag = async (tag) => {
            try {
                const result = await axios.put(
                    `${SERVER}/api/tags/${tag.id}`,
                    { ...tag },
                    {
                        headers: {
                            "Content-Type": "application/json",
                            "App-Type": "adminPanel",
                        },
                    }
                )
                return result.data
            } catch (error) {
                console.log(error.response.data, "error")
            }
        }
        const result = await modifyTag(action.payload)
        action.payload = {
            result,
        }
    }

    return next(action)
}
