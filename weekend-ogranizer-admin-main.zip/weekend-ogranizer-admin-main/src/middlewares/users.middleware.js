import {
    GET_USERS,
    ADD_USER,
    GET_USER_BY_ID,
    MODIFY_USER,
    DELETE_USER,
    getUsersAction,
} from "actions/users"
import { startProgressAction } from "actions/init"
import { getRolesAction } from "actions/roles"

import axios from "axios"

export const usersMiddleWare = (store) => (next) => async (action) => {
    if (action.type === GET_USER_BY_ID) {
        const getUserById = async (id) => {
            try {
                const result = await axios.get(`${SERVER}/api/users/${id}`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                //тут нужен диспатч сообщения об ошибке
                console.dir(error.response, { depth: null })
            }
        }
        const result = await getUserById(action.payload)
        action.payload = {
            ...result,
        }
    }

    if (action.type === GET_USERS) {
        const getUsers = async () => {
            try {
                const result = await axios.get(`${SERVER}/api/users`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                //тут нужен диспатч сообщения об ошибке
                console.dir(error.response, { depth: null })
            }
        }
        const result = await getUsers()

        store.dispatch(getRolesAction())
        action.payload = {
            result,
        }
        store.dispatch(startProgressAction(false))
    }

    if (action.type === MODIFY_USER) {
        const modifyUser = async (user) => {
            try {
                const result = await axios.put(
                    `${SERVER}/api/users/${user.id}`,
                    { ...user },
                    {
                        headers: {
                            "Content-Type": "application/json",
                            "App-Type": "adminPanel",
                        },
                    }
                )

                return result.data
            } catch (error) {
                //тут нужен диспатч сообщения об ошибке
                console.dir(error.response, { depth: null })
            }
        }
        const result = await modifyUser(action.payload)
        //прогружаем пользователей после добавления
        store.dispatch(getUsersAction())
        action.payload = {
            ...result,
        }
    }

    if (action.type === ADD_USER) {
        const createUser = async (data) => {
            try {
                const result = await axios.post(`${SERVER}/api/users`, data, {
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                //тут нужен диспатч сообщения об ошибке
                console.dir(error.response, { depth: null })
            }
        }
        const result = await createUser(action.payload)
        //прогружаем пользователей после добавления
        store.dispatch(getUsersAction())

        action.payload = {
            ...result,
        }
    }

    if (action.type === DELETE_USER) {
        const deleteUser = async (id) => {
            try {
                const result = await axios.delete(`${SERVER}/api/users/${id}`, {
                    headers: {
                        "Content-Type": "application/json",
                        "App-Type": "adminPanel",
                    },
                })
                return result.data
            } catch (error) {
                console.log(error.response.data)
            }
        }
        const result = await deleteUser(action.payload)
        //прогружаем пользователей после добавления
        store.dispatch(getUsersAction())
        action.payload = {
            ...result,
        }
    }

    return next(action)
}
