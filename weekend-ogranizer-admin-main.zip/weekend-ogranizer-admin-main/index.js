const express = require("express")
require("dotenv").config()
const cors = require("./middlewares/cors.middleware")
const PORT = process.env.PORT || 3000

const app = express()
app.use(cors)
app.use(express.static(__dirname + "/dist"))
app.use(express.json())

app.get("/", (req, res) => {
    res.send("index.html")
})
app.use("/*", async (req, res) => {
    res.redirect("/")
})

app.listen(PORT, () => {
    console.log(`Server start in ${PORT}`)
})
