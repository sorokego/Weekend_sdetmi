const path = require("path")
const { CleanWebpackPlugin } = require("clean-webpack-plugin")
const HtmlWebPackPlugin = require("html-webpack-plugin")
const webpack = require("webpack")

require("dotenv").config()

module.exports = {
    entry: {
        main: "./src/index.jsx",
    },
    output: {
        path: path.resolve(__dirname, "dist"),
        // filename: "budle.[contenthash].js",
        assetModuleFilename: "img/[name][ext]",
        filename: "js/[name].[contenthash].js",
    },
    resolve: {
        extensions: [".js", ".jsx"],
        alias: {
            actions: path.join(__dirname, "src", "store/actions"),
            reducers: path.join(__dirname, "src", "store/reducers"),
            containers: path.join(__dirname, "src", "containers"),
            middlewares: path.join(__dirname, "src", "middlewares"),
            components: path.join(__dirname, "src", "components"),
            asset: path.join(__dirname, "src", "asset"),
        },
    },
    module: {
        rules: [
            {
                test: /\.js(x)?$/,
                include: path.resolve(__dirname, "src"),
                exclude: /(node_modules|bower_components)/,
                use: {
                    loader: "babel-loader",
                    options: {
                        presets: ["@babel/preset-env", "@babel/preset-react"],
                    },
                },
            },

            {
                test: /\.(?:ico|gif|png|jpg|jpeg)$/i,
                type: "asset/resource",
                generator: {
                    filename: "img/[name][ext]",
                },
            },
            {
                test: /\.(woff|woff2|eot|ttf|otf)$/,
                type: "asset/inline",
            },
            {
                test: /\.css$/,
                use: ["style-loader", "css-loader"],
            },
        ],
    },

    plugins: [
        new HtmlWebPackPlugin({
            filename: "index.html",
            title: "Admin Panel",
            base: "/",
            template: "./public/index.html",
        }),

        new webpack.DefinePlugin({
            SERVER: JSON.stringify(process.env.SERVER),
        }),
        new CleanWebpackPlugin(),
    ],
}
