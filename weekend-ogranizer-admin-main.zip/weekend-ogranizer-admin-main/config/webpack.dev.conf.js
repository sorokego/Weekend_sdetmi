const path = require("path")
const { merge } = require("webpack-merge")
const common = require("../webpack.config")
const HtmlWebPackPlugin = require("html-webpack-plugin")
const CompressionPlugin = require("compression-webpack-plugin")
const { CleanWebpackPlugin } = require("clean-webpack-plugin")
const BundleAnalyzerPlugin = require("webpack-bundle-analyzer")
    .BundleAnalyzerPlugin

const webpack = require("webpack")
require("dotenv").config()
const TerserPlugin = require("terser-webpack-plugin")

module.exports = merge(common, {
    mode: "development",
    devtool: "inline-source-map",
    devServer: {
        contentBase: path.join(__dirname, "public"),
        compress: true,
        hot: true,
        port: 9000,
        historyApiFallback: true,
    },
    performance: {
        hints: false,
    },
    optimization: {
        splitChunks: {
            maxInitialRequests: Infinity,
            minSize: 0,
            cacheGroups: {
                vendor: {
                    test: /[\\/]node_modules[\\/]/,
                    reuseExistingChunk: true,
                    name(module) {
                        // получает имя, то есть node_modules/packageName/not/this/part.js
                        // или node_modules/packageName
                        const packageName = module.context.match(
                            /[\\/]node_modules[\\/](.*?)([\\/]|$)/
                        )[1]

                        // имена npm-пакетов можно, не опасаясь проблем, использовать
                        // в URL, но некоторые серверы не любят символы наподобие @
                        return `npm.${packageName.replace("@", "")}`
                    },
                },
            },
            chunks: "all",
            maxSize: 2400000,
        },
        minimize: false,
        minimizer: [
            new TerserPlugin({
                parallel: true,
                cache: true,
                extractComments: "all",
            }),
        ],
    },

    plugins: [
        new CompressionPlugin({
            test: /\.js(\?.*)?$/i,
            algorithm: "gzip",
            threshold: 8192,
        }),

        new CleanWebpackPlugin(),
        new webpack.HotModuleReplacementPlugin(),
    ],
})
