const path = require("path")
const { merge } = require("webpack-merge")
const common = require("../webpack.config")
const HtmlWebPackPlugin = require("html-webpack-plugin")
const CompressionPlugin = require("compression-webpack-plugin")
const { CleanWebpackPlugin } = require("clean-webpack-plugin")

const webpack = require("webpack")
require("dotenv").config()
const TerserPlugin = require("terser-webpack-plugin")

module.exports = merge(common, {
    mode: "production",
    devtool: false,

    performance: {
        hints: "warning",
        maxEntrypointSize: 300000,
        maxAssetSize: 700000,
    },
    optimization: {
        splitChunks: {
            maxInitialRequests: Infinity,
            minSize: 0,
            cacheGroups: {
                vendor: {
                    test: /[\\/]node_modules[\\/]/,
                    reuseExistingChunk: true,
                    filename(pathData) {
                        return `js/vendor/${pathData.chunk.hash}.js`
                    },
                },
            },
            chunks: "all",
            maxSize: 2400000,
        },
        removeAvailableModules: true,
        runtimeChunk: "single",
        minimize: true,
        minimizer: [
            new TerserPlugin({
                parallel: true,
                sourceMap: false,
                cache: true,
                // extractComments: "all",
            }),
        ],
    },

    plugins: [
        // new CompressionPlugin({
        //     test: /\.js(\?.*)?$/i,
        //     algorithm: "gzip",
        //     threshold: 10240,
        // }),

        new CleanWebpackPlugin(),
    ],
})
