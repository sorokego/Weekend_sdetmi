//Default array of images if nothing has come
module.exports = [
  { name: 'noimage.png', type: 'primary' },
  { name: 'noimage.png', type: 'secondary' },
  { name: 'noimage.png', type: 'secondary' },
  { name: 'noimage.png', type: 'secondary' }
];