# weekend-api

# ENV

<ul>
  <li>PORT= параметр порта для старта NodeJS на этот порт будут стучатся за данными</li>
<li>DB_HOST = адрес сервера</li>
<li>DB_USERNAME = логин</li>
<li>DB_PASSWORD = пароль</li>
<li>DB_PORT = Порт Postgres сервера</li>
<li>DB_NAME = Имя базы</li>
<li>SECRET = Ключ для authMiddleware</li>
