export const baseUrl = process.env.REACT_APP_BACKEND_URL;
