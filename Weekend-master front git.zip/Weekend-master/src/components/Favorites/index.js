export { default } from "./Favorites";
